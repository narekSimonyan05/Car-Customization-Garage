package am.aua.garage.ui;

import am.aua.garage.core.*;
import am.aua.garage.core.parts.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;
import am.aua.garage.utils.FileUtils;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Main Swing window of the Garage application.
 * <p>
 * Displays the current vehicle count, capacity and wallet balance, and exposes
 * action buttons that open task-specific dialog frames (add, upgrade, repair,
 * deposit, view details, save, load). Each task is implemented as a private
 * inner {@link JFrame} subclass that operates on the enclosing instance's
 * shared {@link Garage}.
 */
public class GarageFrame extends JFrame implements ActionListener {

    /** The garage being managed by this UI; replaced on a successful load. */
    private Garage garage;
    /** Label showing the current vehicle count and capacity. */
    private JLabel vehiclesLabel;
    /** Label showing the current wallet balance. */
    private JLabel balanceLabel;

    /**
     * Builds the main window with an initial garage seeded with $5000, hooks
     * up the action buttons and installs a confirmation dialog for the close
     * operation.
     */
    public GarageFrame() {
        super("Garage");
        garage = new Garage(new Wallet(new Money(5000.0)));

        setSize(720, 360);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int a = JOptionPane.showConfirmDialog(GarageFrame.this,
                        "Are you sure you want to exit?", "Exit",
                        JOptionPane.YES_NO_OPTION);
                if (a == JOptionPane.YES_OPTION) System.exit(0);
            }
        });

        setLayout(new BorderLayout());

        JLabel title = new JLabel("Welcome to your Garage!", JLabel.CENTER);
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        add(title, BorderLayout.NORTH);

        vehiclesLabel = new JLabel("", JLabel.CENTER);
        balanceLabel  = new JLabel("", JLabel.CENTER);
        JPanel center = new JPanel(new GridLayout(2, 1));
        center.add(vehiclesLabel);
        center.add(balanceLabel);
        add(center, BorderLayout.CENTER);

        JPanel buttons = new JPanel(new FlowLayout());
        String[] labels = {"Add", "Upgrade", "Repair", "Make deposit",
                           "Details", "Save", "Load"};
        for (int i = 0; i < labels.length; i++) {
            JButton b = new JButton(labels[i]);
            b.addActionListener(this);
            buttons.add(b);
        }
        add(buttons, BorderLayout.SOUTH);

        refreshStatus();
    }

    /**
     * Dispatches the main-window button clicks by opening the appropriate
     * task dialog.
     *
     * @param e the action event whose command identifies the requested task
     */
    public void actionPerformed(ActionEvent e) {
        String cmd = e.getActionCommand();
        if (cmd.equals("Add")) new AddVehicleFrame().setVisible(true);
        else if (cmd.equals("Upgrade")) new UpgradeFrame().setVisible(true);
        else if (cmd.equals("Repair")) new RepairFrame().setVisible(true);
        else if (cmd.equals("Make deposit")) new DepositFrame().setVisible(true);
        else if (cmd.equals("Details")) new DetailsFrame().setVisible(true);
        else if (cmd.equals("Save")) new SaveFrame().setVisible(true);
        else if (cmd.equals("Load")) new LoadFrame().setVisible(true);
    }

    /**
     * Refreshes the vehicle-count and balance labels to match the current
     * state of the garage. Called after any operation that mutates the
     * garage.
     */
    public void refreshStatus() {
        vehiclesLabel.setText("Vehicles in garage: " + garage.getVehicleCount()
                + " / " + garage.getMaxCapacity());
        balanceLabel.setText("Balance: " + garage.getWallet().getBalance());
    }

    /**
     * Reads the part variation file located at {@code parts/<name>.txt} and
     * returns its trimmed UTF-8 contents.
     *
     * @param name the variation label whose file should be read
     * @return the file contents, with leading and trailing whitespace removed
     * @throws IOException if the file cannot be read
     */
    private static String loadVariation(String name) throws IOException {
        byte[] bytes = Files.readAllBytes(Paths.get("parts", name + ".txt"));
        return new String(bytes, StandardCharsets.UTF_8).trim();
    }

    /**
     * Returns the list of variation labels matching the part position used in
     * {@link PartLists#PART_NAMES}.
     *
     * @param partIndex the zero-based index into {@link PartLists#PART_NAMES}
     * @return the matching array of variation labels, or an empty array if
     *         {@code partIndex} is out of range
     */
    private static String[] variationsFor(int partIndex) {
        switch (partIndex) {
            case 0:  return PartLists.ACCUMULATOR;
            case 1:  return PartLists.AMORTIZATION;
            case 2:  return PartLists.BRAKEPADS;
            case 3:  return PartLists.BUMPER;
            case 4:  return PartLists.ENGINE;
            case 5:  return PartLists.GEARBOX;
            case 6:  return PartLists.LIGHTS;
            case 7:  return PartLists.RIMS;
            case 8:  return PartLists.SIDEMIRROR;
            case 9:  return PartLists.TIRES;
            case 10: return PartLists.WINDSCREEN;
            default: return new String[0];
        }
    }

    /**
     * Static holder for the predefined part variation labels and the
     * human-readable part names used by the upgrade dialogs. Each label
     * corresponds to a file in the {@code parts/} directory.
     */
    private static class PartLists {
        /** Accumulator variation labels. */
        static final String[] ACCUMULATOR = {
                "AgedNeedsReplacementBattery", "CityCarLightBattery",
                "HeavyDutyCommercialBattery", "HighCapacityNearNewBattery",
                "MidLargeFreshBattery", "MidsizeAgingBattery", "StandardSedanBattery"
        };
        /** Amortization variation labels. */
        static final String[] AMORTIZATION = {
                "AirShockAdjustable", "AirShockBrandNewAdjustable", "AirShockFixed",
                "GasShockAdjustable", "GasShockFixed", "GasShockLowWearFixed",
                "HydraulicShockAdjustable", "HydraulicShockFixed",
                "HydraulicShockNearNewAdjustable"
        };
        /** Brake-pad variation labels. */
        static final String[] BRAKEPADS = {
                "CeramicNearNewWithABS", "CeramicNoABS", "CeramicWithABS",
                "MetallicLowWearWithABS", "MetallicNoABS", "MetallicWithABS",
                "OrganicMidWearNoABS", "OrganicNoABS", "OrganicWithABS"
        };
        /** Bumper variation labels. */
        static final String[] BUMPER = {
                "FrontCarbonLuxuryWithSensor", "FrontCarbonRacing", "FrontPlasticBudget",
                "FrontSteelHeavyDuty", "RearCarbonSport", "RearPlasticBudget",
                "RearSteelTowingReady"
        };
        /** Engine variation labels. */
        static final String[] ENGINE = {
                "DieselEconomyNaturallyAspirated", "DieselHeavyDutyTurbo",
                "DieselSportSUVTurbo", "ElectricCityCommuter", "ElectricHighPerformance",
                "HybridEcoCommuter", "HybridMidPerformanceTurbo", "HybridSportPerformance",
                "PetrolEconomyNaturallyAspirated", "PetrolPerformanceTurbo",
                "PetrolStandardSedanNaturallyAspirated"
        };
        /** Gearbox variation labels. */
        static final String[] GEARBOX = {
                "AutomaticAllWheelDrive", "AutomaticTwoWheelDrive",
                "ManualAllWheelDrive", "ManualTwoWheelDrive"
        };
        /** Light variation labels. */
        static final String[] LIGHTS = {
                "HalogenStaticBasic", "HalogenStaticWithDRL", "LaserAdaptiveLuxury",
                "LaserStaticPerformance", "LedAdaptiveModern", "LedStaticEconomy",
                "XenonAdaptivePremium", "XenonAdaptiveSportNoDRL", "XenonStaticBasic"
        };
        /** Rim variation labels. */
        static final String[] RIMS = {
                "AlloySportPerformance19inch7spoke", "AlloyStandardSedan17inch5spoke",
                "CarbonLuxuryShowcar22inch8spoke", "CarbonRacing20inch5spoke",
                "CarbonSport19inch7spoke", "SteelCompactCar16inch5spoke",
                "SteelEconomy15inch5spoke", "SteelTruck17inch6spoke"
        };
        /** Side-mirror variation labels. */
        static final String[] SIDEMIRROR = {
                "LeftBasicNoCamera", "LeftPremiumWithCamera",
                "RightBasicNoCamera", "RightPremiumWithCamera"
        };
        /** Tire variation labels. */
        static final String[] TIRES = {
                "AllSeasonLargeSUV20inch", "AllSeasonMidSUV18inch",
                "AllSeasonStandardSedan17inch", "SummerCity15inch",
                "SummerCompactCar16inch", "SummerSport19inch",
                "WinterCityCommuter15inch", "WinterPerformance18inch",
                "WinterStandardSedan17inch"
        };
        /** Windscreen variation labels. */
        static final String[] WINDSCREEN = {
                "BasicNoFeatures", "HeatedOnly", "HeatedWithHud", "HeatedWithRainSensor",
                "HudOnly", "PremiumAllFeatures", "RainSensorOnly", "RainSensorWithHud"
        };
        /**
         * Display names of upgradable parts. The position in this array maps
         * to the index understood by {@link #variationsFor(int)}.
         */
        static final String[] PART_NAMES = {
                "Accumulator", "Amortization", "Brake pads", "Bumper", "Engine",
                "Gearbox", "Lights", "Rims", "Side mirror", "Tires", "Windscreen"
        };
    }

    /**
     * Dialog frame that gathers the inputs needed to construct a new
     * {@link Vehicle} (either a {@link Sedan} or an {@link Suv}) and adds it
     * to the enclosing {@link GarageFrame}'s garage after charging the wallet.
     */
    private class AddVehicleFrame extends JFrame implements ActionListener {

        /** Combo box for the vehicle type ({@code Sedan} or {@code SUV}). */
        private JComboBox<String> typeCombo;
        /** Combo box for the vehicle color. */
        private JComboBox<am.aua.garage.core.Color> colorCombo;
        /** Free-form text fields for brand, name and numeric SUV/Sedan-specific values. */
        private JTextField brandField, nameField, hpField, roofField, towField;
        /** Sedan-specific checkboxes for sunroof and sport-mode options. */
        private JCheckBox sunroofChk, sportModeChk;
        /** SUV-specific checkboxes for drivetrain and off-road options. */
        private JCheckBox is4x4Chk, lockingDiffChk, hillDescentChk;
        /** Combo boxes for selecting a predefined variation of each part. */
        private JComboBox<String> accumulatorCombo, amortizationCombo, brakePadsCombo,
                bumperCombo, engineCombo, gearboxCombo, lightsCombo, rimsCombo,
                sideMirrorCombo, tiresCombo, windscreenCombo;

        /**
         * Builds the form, populating combo boxes with the predefined part
         * variation labels and seeding text fields with sensible defaults.
         */
        public AddVehicleFrame() {
            super("Add Vehicle");
            setSize(440, 720);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            typeCombo  = new JComboBox<String>(new String[]{"Sedan", "SUV"});
            brandField = new JTextField("Generic");
            nameField  = new JTextField("My Car");
            colorCombo = new JComboBox<am.aua.garage.core.Color>(am.aua.garage.core.Color.values());

            accumulatorCombo  = new JComboBox<String>(PartLists.ACCUMULATOR);
            amortizationCombo = new JComboBox<String>(PartLists.AMORTIZATION);
            brakePadsCombo    = new JComboBox<String>(PartLists.BRAKEPADS);
            bumperCombo       = new JComboBox<String>(PartLists.BUMPER);
            engineCombo       = new JComboBox<String>(PartLists.ENGINE);
            gearboxCombo      = new JComboBox<String>(PartLists.GEARBOX);
            lightsCombo       = new JComboBox<String>(PartLists.LIGHTS);
            rimsCombo         = new JComboBox<String>(PartLists.RIMS);
            sideMirrorCombo   = new JComboBox<String>(PartLists.SIDEMIRROR);
            tiresCombo        = new JComboBox<String>(PartLists.TIRES);
            windscreenCombo   = new JComboBox<String>(PartLists.WINDSCREEN);

            sunroofChk     = new JCheckBox("Sunroof");
            sportModeChk   = new JCheckBox("Sport mode");
            hpField        = new JTextField("200");
            is4x4Chk       = new JCheckBox("4x4");
            lockingDiffChk = new JCheckBox("Locking differential");
            hillDescentChk = new JCheckBox("Hill descent control");
            roofField      = new JTextField("150");
            towField       = new JTextField("2000");

            JPanel form = new JPanel(new GridLayout(0, 2, 6, 6));
            form.add(new JLabel("Type:"));         form.add(typeCombo);
            form.add(new JLabel("Brand:"));        form.add(brandField);
            form.add(new JLabel("Name:"));         form.add(nameField);
            form.add(new JLabel("Color:"));        form.add(colorCombo);
            form.add(new JLabel("Accumulator:"));  form.add(accumulatorCombo);
            form.add(new JLabel("Amortization:")); form.add(amortizationCombo);
            form.add(new JLabel("Brake pads:"));   form.add(brakePadsCombo);
            form.add(new JLabel("Bumper:"));       form.add(bumperCombo);
            form.add(new JLabel("Engine:"));       form.add(engineCombo);
            form.add(new JLabel("Gearbox:"));      form.add(gearboxCombo);
            form.add(new JLabel("Lights:"));       form.add(lightsCombo);
            form.add(new JLabel("Rims:"));         form.add(rimsCombo);
            form.add(new JLabel("Side mirror:"));  form.add(sideMirrorCombo);
            form.add(new JLabel("Tires:"));        form.add(tiresCombo);
            form.add(new JLabel("Windscreen:"));   form.add(windscreenCombo);
            form.add(new JLabel("Sedan:"));        form.add(sunroofChk);
            form.add(new JLabel(""));              form.add(sportModeChk);
            form.add(new JLabel("Horsepower:"));   form.add(hpField);
            form.add(new JLabel("SUV:"));          form.add(is4x4Chk);
            form.add(new JLabel(""));              form.add(lockingDiffChk);
            form.add(new JLabel(""));              form.add(hillDescentChk);
            form.add(new JLabel("Roof rack:"));    form.add(roofField);
            form.add(new JLabel("Towing kg:"));    form.add(towField);

            JButton cancel = new JButton("Cancel");
            JButton add    = new JButton("Add");
            cancel.addActionListener(this);
            add.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(add);

            setLayout(new BorderLayout());
            add(new JScrollPane(form), BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Routes the dialog buttons: {@code Cancel} disposes the window,
         * {@code Add} forwards to {@link #onAdd()}.
         *
         * @param e the action event whose command identifies the button
         */
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("Cancel")) { dispose(); return; }
            if (e.getActionCommand().equals("Add"))    onAdd();
        }

        /**
         * Validates the form, builds the requested vehicle, asks for cost
         * confirmation, charges the wallet and adds the vehicle to the
         * garage. All failure modes (parse errors, domain validation,
         * insufficient funds) are reported through {@link JOptionPane} dialogs
         * without disposing the form.
         */
        private void onAdd() {
            if (garage.getVehicleCount() >= garage.getMaxCapacity()) {
                JOptionPane.showMessageDialog(this, "Garage is full.");
                return;
            }
            Vehicle vehicle;
            Money cost;
            try {
                Accumulator accumulator   = new Accumulator( loadVariation((String) accumulatorCombo.getSelectedItem()));
                Amortization amortization = new Amortization(loadVariation((String) amortizationCombo.getSelectedItem()));
                BrakePads brakePads       = new BrakePads(   loadVariation((String) brakePadsCombo.getSelectedItem()));
                Bumper bumper             = new Bumper(      loadVariation((String) bumperCombo.getSelectedItem()));
                Engine engine             = new Engine(      loadVariation((String) engineCombo.getSelectedItem()));
                Gearbox gearbox           = new Gearbox(     loadVariation((String) gearboxCombo.getSelectedItem()));
                Lights lights             = new Lights(      loadVariation((String) lightsCombo.getSelectedItem()));
                Rims rims                 = new Rims(        loadVariation((String) rimsCombo.getSelectedItem()));
                SideMirror sideMirror     = new SideMirror(  loadVariation((String) sideMirrorCombo.getSelectedItem()));
                Tires tires               = new Tires(       loadVariation((String) tiresCombo.getSelectedItem()));
                Windscreen windscreen     = new Windscreen(  loadVariation((String) windscreenCombo.getSelectedItem()));

                String brandName = brandField.getText().trim();
                if (brandName.isEmpty()) brandName = "Generic";
                String name = nameField.getText().trim();
                if (name.isEmpty()) name = "Unnamed";
                am.aua.garage.core.Color color =
                        (am.aua.garage.core.Color) colorCombo.getSelectedItem();

                Brand brand = new Brand(brandName, "+1-555-0100",
                        "info@" + brandName.toLowerCase() + ".com",
                        "https://" + brandName.toLowerCase() + ".com",
                        "USA", new Brand.Location[0], false, 2000);

                if (typeCombo.getSelectedItem().equals("Sedan")) {
                    int hp = Integer.parseInt(hpField.getText().trim());
                    vehicle = new Sedan(brand, name, color, accumulator, brakePads,
                            engine, gearbox, amortization, bumper, lights, rims,
                            sideMirror, tires, windscreen,
                            sunroofChk.isSelected(), sportModeChk.isSelected(), hp);
                } else {
                    int roof = Integer.parseInt(roofField.getText().trim());
                    int tow  = Integer.parseInt(towField.getText().trim());
                    vehicle = new Suv(brand, name, color, accumulator, brakePads,
                            engine, gearbox, amortization, bumper, lights, rims,
                            sideMirror, tires, windscreen,
                            is4x4Chk.isSelected(), lockingDiffChk.isSelected(),
                            hillDescentChk.isSelected(), roof, tow);
                }
                cost = vehicle.calculateRepairCost();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter valid numbers.");
                return;
            } catch (UnrealisticException ex) {
                JOptionPane.showMessageDialog(this, "Invalid value: " + ex.getMessage());
                return;
            } catch (MalformedStringException ex) {
                JOptionPane.showMessageDialog(this, "Invalid part data: " + ex.getMessage());
                return;
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Couldn't read part file: " + ex.getMessage());
                return;
            }

            int answer = JOptionPane.showConfirmDialog(this,
                    "Total cost: " + cost
                            + "\nBalance: " + garage.getWallet().getBalance()
                            + "\nAdd this vehicle?",
                    "Confirm", JOptionPane.YES_NO_OPTION);
            if (answer != JOptionPane.YES_OPTION) return;

            if (!garage.charge(cost)) {
                JOptionPane.showMessageDialog(this, "Insufficient funds.");
                return;
            }
            garage.addNewVehicle(vehicle);
            refreshStatus();
            JOptionPane.showMessageDialog(this, "Vehicle added.");
            dispose();
        }
    }

    /**
     * Dialog frame that lets the user replace a single part of an existing
     * vehicle with a predefined variation, charging the wallet for the cost.
     */
    private class UpgradeFrame extends JFrame implements ActionListener {

        /** Combo box listing the vehicles currently in the garage. */
        private JComboBox<String> vehicleCombo;
        /** Combo box listing the upgradable parts. */
        private JComboBox<String> partCombo;
        /** Combo box listing the variations for the part selected in {@link #partCombo}. */
        private JComboBox<String> variationCombo;

        /**
         * Builds the form, populating the vehicle list from the garage and
         * the variation list from {@link PartLists}.
         */
        public UpgradeFrame() {
            super("Upgrade Vehicle");
            setSize(420, 220);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            vehicleCombo   = new JComboBox<String>();
            partCombo      = new JComboBox<String>(PartLists.PART_NAMES);
            variationCombo = new JComboBox<String>();
            partCombo.addActionListener(this);

            Vehicle[] vs = garage.getVehicles();
            if (vs != null) {
                for (int i = 0; i < vs.length; i++) {
                    vehicleCombo.addItem((i + 1) + ". " + vs[i].getBrand().getName()
                            + " (" + vs[i].getClass().getSimpleName() + ")");
                }
            }
            updateVariations();

            JPanel form = new JPanel(new GridLayout(3, 2, 6, 6));
            form.add(new JLabel("Vehicle:"));   form.add(vehicleCombo);
            form.add(new JLabel("Part:"));      form.add(partCombo);
            form.add(new JLabel("Variation:")); form.add(variationCombo);

            JButton cancel  = new JButton("Cancel");
            JButton upgrade = new JButton("Upgrade");
            cancel.addActionListener(this);
            upgrade.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(upgrade);

            setLayout(new BorderLayout());
            add(form,    BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Repopulates the variation combo box after a different part has
         * been selected.
         */
        private void updateVariations() {
            variationCombo.removeAllItems();
            String[] vs = variationsFor(partCombo.getSelectedIndex());
            for (int i = 0; i < vs.length; i++) variationCombo.addItem(vs[i]);
        }

        /**
         * Reacts to combo-box and button events: changes to the part combo
         * trigger a variation refresh; {@code Cancel} disposes the window
         * and {@code Upgrade} forwards to {@link #onUpgrade()}.
         *
         * @param e the action event from a combo box or button
         */
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == partCombo) { updateVariations(); return; }
            String cmd = e.getActionCommand();
            if (cmd.equals("Cancel"))  { dispose(); return; }
            if (cmd.equals("Upgrade")) onUpgrade();
        }

        /**
         * Loads the chosen variation, builds the matching part instance,
         * asks for cost confirmation, charges the wallet and applies the
         * change to the selected vehicle. All failure modes are reported
         * through {@link JOptionPane} dialogs.
         */
        private void onUpgrade() {
            if (garage.getVehicleCount() == 0) {
                JOptionPane.showMessageDialog(this, "There are no vehicles.");
                return;
            }
            int vIdx = vehicleCombo.getSelectedIndex();
            if (vIdx < 0) return;
            Vehicle v = garage.getVehicle(vIdx);

            String variation = (String) variationCombo.getSelectedItem();
            if (variation == null) return;

            try {
                String content = loadVariation(variation);
                Money cost;
                int p = partCombo.getSelectedIndex();
                if (p == 0) {
                    Accumulator part = new Accumulator(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeAccumulator(part);
                } else if (p == 1) {
                    Amortization part = new Amortization(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeAmortization(part);
                } else if (p == 2) {
                    BrakePads part = new BrakePads(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeBrakePads(part);
                } else if (p == 3) {
                    Bumper part = new Bumper(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeBumper(part);
                } else if (p == 4) {
                    Engine part = new Engine(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeEngine(part);
                } else if (p == 5) {
                    Gearbox part = new Gearbox(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeGearbox(part);
                } else if (p == 6) {
                    Lights part = new Lights(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeLights(part);
                } else if (p == 7) {
                    Rims part = new Rims(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeRims(part);
                } else if (p == 8) {
                    SideMirror part = new SideMirror(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeSideMirrors(part);
                } else if (p == 9) {
                    Tires part = new Tires(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeTires(part);
                } else if (p == 10) {
                    Windscreen part = new Windscreen(content);
                    cost = part.calculateRepairCost();
                    if (!confirmAndCharge(cost)) return;
                    v.changeWindScreen(part);
                } else {
                    return;
                }
                refreshStatus();
                JOptionPane.showMessageDialog(this, "Part upgraded.");
                dispose();
            } catch (MalformedStringException ex) {
                JOptionPane.showMessageDialog(this, "Bad part data: " + ex.getMessage());
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Couldn't read part file: " + ex.getMessage());
            }
        }

        /**
         * Shows the cost and current balance to the user, asks for
         * confirmation and charges the wallet on agreement.
         *
         * @param cost the price to confirm and deduct
         * @return {@code true} if the user confirmed and the wallet was
         *         successfully charged; {@code false} otherwise
         */
        private boolean confirmAndCharge(Money cost) {
            int ans = JOptionPane.showConfirmDialog(this,
                    "Cost: " + cost
                            + "\nBalance: " + garage.getWallet().getBalance()
                            + "\nProceed?",
                    "Confirm", JOptionPane.YES_NO_OPTION);
            if (ans != JOptionPane.YES_OPTION) return false;
            if (!garage.charge(cost)) {
                JOptionPane.showMessageDialog(this, "Insufficient funds.");
                return false;
            }
            return true;
        }
    }

    /**
     * Dialog frame that calculates the repair cost for a selected vehicle
     * and, on user confirmation, deducts it from the wallet.
     */
    private class RepairFrame extends JFrame implements ActionListener {

        /** Combo box listing the vehicles currently in the garage. */
        private JComboBox<String> vehicleCombo;

        /**
         * Builds the form, populating the vehicle list from the garage.
         */
        public RepairFrame() {
            super("Repair Vehicle");
            setSize(360, 140);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            vehicleCombo = new JComboBox<String>();
            Vehicle[] vs = garage.getVehicles();
            if (vs != null) {
                for (int i = 0; i < vs.length; i++) {
                    vehicleCombo.addItem((i + 1) + ". " + vs[i].getBrand().getName()
                            + " (" + vs[i].getClass().getSimpleName() + ")");
                }
            }

            JPanel form = new JPanel(new GridLayout(1, 2, 6, 6));
            form.add(new JLabel("Vehicle:"));
            form.add(vehicleCombo);

            JButton cancel = new JButton("Cancel");
            JButton repair = new JButton("Repair");
            cancel.addActionListener(this);
            repair.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(repair);

            setLayout(new BorderLayout());
            add(form, BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Routes the dialog buttons: {@code Cancel} disposes the window,
         * {@code Repair} forwards to {@link #onRepair()}.
         *
         * @param e the action event whose command identifies the button
         */
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            if (cmd.equals("Cancel")) { dispose(); return; }
            if (cmd.equals("Repair")) onRepair();
        }

        /**
         * Computes the repair cost for the selected vehicle, asks for
         * confirmation and withdraws the cost from the wallet on agreement.
         * Aborts gracefully when the garage is empty or funds are
         * insufficient.
         */
        private void onRepair() {
            if (garage.getVehicleCount() == 0) {
                JOptionPane.showMessageDialog(this, "There are no vehicles.");
                return;
            }
            int idx = vehicleCombo.getSelectedIndex();
            if (idx < 0) return;
            Vehicle v = garage.getVehicle(idx);
            Money cost = v.calculateRepairCost();
            Wallet w = garage.getWallet();

            int answer = JOptionPane.showConfirmDialog(this,
                    "Repair cost: " + cost
                            + "\nBalance: " + w.getBalance()
                            + "\nProceed?",
                    "Confirm", JOptionPane.YES_NO_OPTION);
            if (answer != JOptionPane.YES_OPTION) return;
            if (w.getBalance().compareTo(cost) < 0) {
                JOptionPane.showMessageDialog(this, "Insufficient funds.");
                return;
            }
            w.withdraw(cost);
            refreshStatus();
            JOptionPane.showMessageDialog(this, "Repair complete.");
            dispose();
        }
    }

    /**
     * Dialog frame for depositing funds into the garage wallet.
     */
    private class DepositFrame extends JFrame implements ActionListener {

        /** Text field for the deposit amount. */
        private JTextField amountField;

        /**
         * Builds the deposit form and shows the current wallet balance.
         */
        public DepositFrame() {
            super("Make Deposit");
            setSize(320, 150);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            amountField = new JTextField();
            JPanel form = new JPanel(new GridLayout(2, 2, 6, 6));
            form.add(new JLabel("Amount ($):"));
            form.add(amountField);
            form.add(new JLabel("Balance:"));
            form.add(new JLabel(garage.getWallet().getBalance().toString()));

            JButton cancel  = new JButton("Cancel");
            JButton deposit = new JButton("Deposit");
            cancel.addActionListener(this);
            deposit.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(deposit);

            setLayout(new BorderLayout());
            add(form, BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Routes the dialog buttons: {@code Cancel} disposes the window,
         * {@code Deposit} forwards to {@link #onDeposit()}.
         *
         * @param e the action event whose command identifies the button
         */
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            if (cmd.equals("Cancel"))  { dispose(); return; }
            if (cmd.equals("Deposit")) onDeposit();
        }

        /**
         * Parses the entered amount and, if positive, deposits it into the
         * wallet. Reports the new balance on success and an error otherwise.
         */
        private void onDeposit() {
            try {
                double amount = Double.parseDouble(amountField.getText().trim());
                if (amount <= 0) {
                    JOptionPane.showMessageDialog(this, "Amount must be positive.");
                    return;
                }
                garage.getWallet().deposit(new Money(amount));
                refreshStatus();
                JOptionPane.showMessageDialog(this,
                        "New balance: " + garage.getWallet().getBalance());
                dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid number.");
            }
        }
    }

    /**
     * Dialog frame that displays detailed information for either every
     * vehicle in the garage or a single selected vehicle.
     */
    private class DetailsFrame extends JFrame implements ActionListener {

        /** Combo box selecting "all vehicles" or a specific vehicle. */
        private JComboBox<String> vehicleCombo;
        /** Read-only text area showing the formatted vehicle details. */
        private JTextArea detailsArea;

        /**
         * Builds the form, populating the vehicle list and rendering the
         * initial details view.
         */
        public DetailsFrame() {
            super("Vehicle Details");
            setSize(560, 480);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            vehicleCombo = new JComboBox<String>();
            vehicleCombo.addItem("All vehicles");
            Vehicle[] vs = garage.getVehicles();
            if (vs != null) {
                for (int i = 0; i < vs.length; i++) {
                    vehicleCombo.addItem((i + 1) + ". " + vs[i].getBrand().getName()
                            + " (" + vs[i].getClass().getSimpleName() + ")");
                }
            }
            vehicleCombo.addActionListener(this);

            detailsArea = new JTextArea();
            detailsArea.setEditable(false);
            detailsArea.setFont(new Font("Monospaced", Font.PLAIN, 13));

            JPanel top = new JPanel(new GridLayout(1, 2, 6, 6));
            top.add(new JLabel("Vehicle:"));
            top.add(vehicleCombo);

            JButton close = new JButton("Close");
            close.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(close);

            setLayout(new BorderLayout());
            add(top, BorderLayout.NORTH);
            add(new JScrollPane(detailsArea), BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);

            showDetails();
        }

        /**
         * Refreshes the details view when the selection changes and disposes
         * the window when the {@code Close} button is pressed.
         *
         * @param e the action event from the combo box or close button
         */
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == vehicleCombo) { showDetails(); return; }
            if (e.getActionCommand().equals("Close")) dispose();
        }

        /**
         * Renders either every vehicle (separated by a header line) or a
         * single chosen vehicle into {@link #detailsArea}.
         */
        private void showDetails() {
            Vehicle[] vs = garage.getVehicles();
            if (vs == null || vs.length == 0) {
                detailsArea.setText("The garage is empty.");
                return;
            }
            int sel = vehicleCombo.getSelectedIndex();
            String text = "";
            if (sel <= 0) {
                for (int i = 0; i < vs.length; i++) {
                    text += "--- Vehicle " + (i + 1) + " ---\n" + vs[i] + "\n\n";
                }
            } else {
                text = vs[sel - 1].toString();
            }
            detailsArea.setText(text);
            detailsArea.setCaretPosition(0);
        }
    }

    /**
     * Dialog frame that persists the current garage to disk via
     * {@link FileUtils}.
     */
    private class SaveFrame extends JFrame implements ActionListener {

        /** Text field for an optional destination path. */
        private JTextField pathField;

        /**
         * Builds the save form, defaulting the path field to empty so that
         * {@link FileUtils#saveGarage(String)} is used.
         */
        public SaveFrame() {
            super("Save Garage");
            setSize(420, 160);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            pathField = new JTextField();

            JPanel form = new JPanel(new GridLayout(2, 1, 6, 6));
            JPanel row1 = new JPanel(new GridLayout(1, 2, 6, 6));
            row1.add(new JLabel("Path:"));
            row1.add(pathField);
            form.add(row1);
            form.add(new JLabel("Leave blank for default (./mygarage.txt)."));

            JButton cancel = new JButton("Cancel");
            JButton save   = new JButton("Save");
            cancel.addActionListener(this);
            save.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(save);

            setLayout(new BorderLayout());
            add(form, BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Routes the dialog buttons: {@code Cancel} disposes the window,
         * {@code Save} forwards to {@link #onSave()}.
         *
         * @param e the action event whose command identifies the button
         */
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            if (cmd.equals("Cancel")) { dispose(); return; }
            if (cmd.equals("Save"))   onSave();
        }

        /**
         * Writes the garage to the given path (or the default if blank).
         * Reports success or the I/O error message.
         */
        private void onSave() {
            String path = pathField.getText().trim();
            try {
                String storage = garage.getStorageString();
                if (path.equals("")) FileUtils.saveGarage(storage);
                else                 FileUtils.saveGarage(storage, path);
                JOptionPane.showMessageDialog(this, "Saved.");
                dispose();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Save failed: " + ex.getMessage());
            }
        }
    }

    /**
     * Dialog frame that replaces the in-memory garage with one loaded from
     * disk via {@link FileUtils}.
     */
    private class LoadFrame extends JFrame implements ActionListener {

        /** Text field for an optional source path. */
        private JTextField pathField;

        /**
         * Builds the load form, defaulting the path field to empty so that
         * {@link FileUtils#loadGarage()} is used.
         */
        public LoadFrame() {
            super("Load Garage");
            setSize(420, 160);
            setLocationRelativeTo(GarageFrame.this);
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);

            pathField = new JTextField();

            JPanel form = new JPanel(new GridLayout(2, 1, 6, 6));
            JPanel row1 = new JPanel(new GridLayout(1, 2, 6, 6));
            row1.add(new JLabel("Path:"));
            row1.add(pathField);
            form.add(row1);
            form.add(new JLabel("Leave blank for default (./mygarage.txt)."));

            JButton cancel = new JButton("Cancel");
            JButton load   = new JButton("Load");
            cancel.addActionListener(this);
            load.addActionListener(this);
            JPanel buttons = new JPanel(new FlowLayout());
            buttons.add(cancel);
            buttons.add(load);

            setLayout(new BorderLayout());
            add(form, BorderLayout.CENTER);
            add(buttons, BorderLayout.SOUTH);
        }

        /**
         * Routes the dialog buttons: {@code Cancel} disposes the window,
         * {@code Load} forwards to {@link #onLoad()}.
         *
         * @param e the action event whose command identifies the button
         */
        public void actionPerformed(ActionEvent e) {
            String cmd = e.getActionCommand();
            if (cmd.equals("Cancel")) { dispose(); return; }
            if (cmd.equals("Load"))   onLoad();
        }

        /**
         * Reads the garage from the given path (or the default if blank),
         * replaces the in-memory garage on success, refreshes the main
         * window's status labels, and reports the outcome.
         */
        private void onLoad() {
            String path = pathField.getText().trim();
            Garage loaded;
            try {
                if (path.equals("")) loaded = FileUtils.loadGarage();
                else                 loaded = FileUtils.loadGarage(path);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Load failed: " + ex.getMessage());
                return;
            }
            if (loaded == null) {
                JOptionPane.showMessageDialog(this, "File missing or corrupted.");
                return;
            }
            garage = loaded;
            refreshStatus();
            JOptionPane.showMessageDialog(this,
                    "Loaded. Vehicles: " + loaded.getVehicleCount()
                            + ", Balance: " + loaded.getWallet().getBalance());
            dispose();
        }
    }
}
