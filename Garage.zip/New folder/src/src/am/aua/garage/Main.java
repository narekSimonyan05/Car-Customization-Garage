package am.aua.garage;

import am.aua.garage.cli.GarageConsole;
import am.aua.garage.ui.GarageFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {

        //args = new String[]{"-cli"};
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
        }catch (Exception e){e.printStackTrace();}

        if(args.length == 0){
            GarageFrame ui = new GarageFrame();
            ui.setVisible(true);


        } else if(args[0].equals("-cli")){
            GarageConsole console = new GarageConsole();
            console.start();
        }

    }
}