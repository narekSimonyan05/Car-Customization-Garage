package am.aua.garage.utils;

import am.aua.garage.core.Garage;

import java.io.*;
import java.util.Scanner;

/**
 * Utility methods for persisting and loading a {@link Garage} to and from a
 * text file, and for reading pre-defined part configuration files used by the
 * interactive interfaces.
 * <p>
 * All methods are static; this class is not intended to be instantiated.
 */
public class FileUtils {

    /** Default file path used when callers do not supply an explicit path. */
    private static String defaultPath = "./mygarage.txt";

    /**
     * Saves the given storage string to the {@linkplain #defaultPath default file}.
     *
     * @param storageString the serialized garage representation produced by
     *                      {@link Garage#getStorageString()}
     * @throws IOException if the file cannot be written
     */
    public static void saveGarage(String storageString) throws IOException {
        saveGarage(storageString, defaultPath);
    }

    /**
     * Saves the given storage string to the specified file path.
     *
     * @param storageString the serialized garage representation produced by
     *                      {@link Garage#getStorageString()}
     * @param path          the destination file path
     * @throws IOException if the file cannot be written
     */
    public static void saveGarage(String storageString, String path) throws IOException {
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new FileOutputStream(path));
            pw.println(storageString);
        } catch (IOException e) {
            throw e;
        } finally {
            if (pw != null) {
                pw.close();
            }
        }
    }

    /**
     * Loads a {@link Garage} from the {@linkplain #defaultPath default file}.
     *
     * @return the reconstructed garage, or {@code null} if loading or parsing failed
     * @throws IOException if a low-level I/O error prevents reading the file
     */
    public static Garage loadGarage() throws IOException {
        return loadGarage(defaultPath);
    }

    /**
     * Loads a {@link Garage} from the specified file path. The contents of the
     * file are concatenated and passed to {@link Garage#Garage(String)}.
     * <p>
     * Any exception thrown during reading or parsing is swallowed, in which
     * case this method returns {@code null}.
     *
     * @param path the file path to read from
     * @return the reconstructed garage, or {@code null} if the file is missing
     *         or its contents cannot be parsed
     */
    public static Garage loadGarage(String path) {
        Garage result;
        Scanner sc = null;

        try {
            sc = new Scanner(new FileInputStream(path));
            String storageString = "";
            while (sc.hasNextLine()) {
                storageString += sc.nextLine();
            }
            result = new Garage(storageString);
        } catch (Exception e) {
            result = null;
        } finally {
            if (sc != null) {
                sc.close();
            }
        }
        return result;
    }

    /**
     * Prompts the user (via the supplied {@link Scanner}) to choose one of the
     * given variation labels, then reads and returns the first line of the
     * corresponding part file located at {@code parts/<label>.txt}.
     * <p>
     * Re-prompts on invalid numeric input and prints diagnostic messages if the
     * file is missing or empty.
     *
     * @param sc       the scanner to read user input from
     * @param options  the list of valid variation labels presented to the user
     * @param partName a human-readable part name used in the prompts
     * @return the storage string read from the chosen part file, or
     *         {@code null} if the file was missing or empty
     */
    public static String pickAndLoadPart(Scanner sc, String[] options, String partName){
        System.out.println("Available " + partName + " variations:");
        for (int i = 0; i < options.length; i++){
            System.out.println((i + 1) + ": " + options[i]);
        }
        int input = readInt(sc, "> ");
        while (input < 1 || input > options.length){
            System.out.println("Invalid choice.");
            input = readInt(sc, "> ");
        }
        String label = options[input - 1];
        String path = "parts/" + label + ".txt";
        Scanner fileScanner = null;
        try {
            fileScanner = new Scanner(new FileInputStream(path));
            if (!fileScanner.hasNextLine()){
                System.out.println("File is empty: " + path);
                return null;
            }
            return fileScanner.nextLine();
        } catch (FileNotFoundException e){
            System.out.println("File not found: " + path);
            return null;
        } finally {
            if (fileScanner != null) fileScanner.close();
        }
    }

    /**
     * Reads an integer from the supplied scanner, re-prompting until a valid
     * integer is provided.
     *
     * @param sc     the scanner to read input from
     * @param prompt the prompt printed before each read attempt
     * @return the integer entered by the user
     */
    private static int readInt(Scanner sc, String prompt){
        while (true){
            System.out.println(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e){
                System.out.println("Invalid integer. Please try again.");
            }
        }
    }
}
