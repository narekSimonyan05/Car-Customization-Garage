package am.aua.garage.cli;

import am.aua.garage.core.*;
import am.aua.garage.core.parts.*;
import am.aua.garage.exceptions.UnrealisticException;

import java.util.Scanner;

/**
 * Interactively builds {@link Vehicle} instances and their constituent parts
 * by prompting the user on the console.
 * <p>
 * Each {@code create*} method walks the user through the inputs required to
 * construct one part (or one whole vehicle) and validates the input by
 * delegating to the corresponding domain constructor; on a failed validation
 * (an {@link UnrealisticException}) the user is asked to try again.
 */
public class VehicleBuilder {
    /** Scanner used for all interactive console input. */
    private final Scanner sc;

    /**
     * Creates a new builder that will read user input from the supplied scanner.
     *
     * @param sc the scanner bound to the input stream to prompt the user on
     */
    public VehicleBuilder(Scanner sc){
        this.sc = sc;
    }

    /**
     * Prompts the user for every property of a vehicle (type, brand, name,
     * color and all parts) and constructs either a {@link Sedan} or a
     * {@link Suv} accordingly.
     *
     * @return the fully-built vehicle
     * @throws UnrealisticException if any aggregated part or the vehicle itself
     *                              fails domain validation despite the
     *                              per-part retry loops
     */
    public Vehicle createVehicle() throws UnrealisticException {
        String type = readChoice(
                "Choose one of the following vehicle types: \n1: (S)edan\n2: S(U)V",
                "1","S","2","U");

        System.out.println("--- Brand ---");
        Brand brand = createBrand();

        System.out.println("The vehicle name: ");
        String name = sc.nextLine();

        String colorAnswer = readChoice(
                "Choose the color: \n1: (B)lack\n2: (W)hite\n3: (G)reen\n4: B(L)ue\n5: (R)ed",
                "1","B","2","W","3","G","4","L","5","R");
        Color color;
        switch (colorAnswer){
            case "1","B":
                color = Color.BLACK;
                break;
            case "2","W":
                color = Color.WHITE;
                break;
            case "3","G":
                color = Color.GREEN;
                break;
            case "4","L":
                color = Color.BLUE;
                break;
            default:
                color = Color.RED;
        }

        System.out.println("--- Accumulator ---");
        Accumulator accumulator = createAccumulator();

        System.out.println("--- Brake Pads ---");
        BrakePads brakePads = createBrakePads();

        System.out.println("--- Engine ---");
        Engine engine = createEngine();

        System.out.println("--- Gearbox ---");
        Gearbox gearbox = createGearbox();

        System.out.println("--- Amortization ---");
        Amortization amortization = createAmortization();

        System.out.println("--- Bumper ---");
        String bumperMaterialAnswer = readChoice(
                "Choose the bumper material.\n1: (P)lastic\n2: (C)arbon\n3: (S)teel",
                "1","P","2","C","3","S");
        boolean hasParkingSensor = readYesNo("Does it have parking sensors?");
        Bumper.Material bumperMaterial;
        switch (bumperMaterialAnswer){
            case "1","P":
                bumperMaterial = Bumper.Material.PLASTIC;
                break;
            case "2","C":
                bumperMaterial = Bumper.Material.CARBON;
                break;
            default:
                bumperMaterial = Bumper.Material.STEEL;
        }
        Bumper frontBumper = new Bumper(Bumper.Position.FRONT, bumperMaterial, hasParkingSensor);
        Bumper rearBumper = new Bumper(Bumper.Position.REAR, bumperMaterial, hasParkingSensor);
        Bumper bumper = frontBumper;

        System.out.println("--- Lights ---");
        Lights lights = createLights();

        System.out.println("--- Rims ---");
        Rims rims = createRims();

        System.out.println("--- Side Mirror ---");
        SideMirror sideMirror = createSideMirror();

        System.out.println("--- Tires ---");
        Tires tires = createTires();

        System.out.println("--- Windscreen ---");
        Windscreen windscreen = createWindscreen();

        if (type.equals("1") || type.equals("S")){
            boolean hasSunRoof = readYesNo("Does it have a sunroof?");
            boolean hasSportMode = readYesNo("Does it have sport mode?");
            int horsepower = readInt("Horsepower: ");

            return new Sedan(brand,name,color,accumulator,brakePads,engine,gearbox,
                    amortization,bumper,lights,rims,sideMirror,tires,windscreen,
                    hasSunRoof,hasSportMode,horsepower);
        } else {
            boolean is4x4 = readYesNo("Is it 4x4?");
            boolean hasLockingDifferential = readYesNo("Does it have a locking differential?");
            boolean hasHillDescentControl = readYesNo("Does it have hill descent control?");
            int roofRackLoadCapacity = readInt("Roof rack load capacity: ");
            int towingCapacityKg = readInt("Towing capacity in kg: ");

            return new Suv(brand,name,color,accumulator,brakePads,engine,gearbox,
                    amortization,bumper,lights,rims,sideMirror,tires,windscreen,
                    is4x4,hasLockingDifferential,hasHillDescentControl,
                    roofRackLoadCapacity,towingCapacityKg);
        }
    }

    /**
     * Prompts the user for accumulator properties and returns a valid
     * {@link Accumulator}, looping until the input passes validation.
     *
     * @return a newly constructed accumulator
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Accumulator createAccumulator() throws UnrealisticException{
        while (true){
            double capacityAh = readDouble("The capacity in Ah: ");
            int voltage = readInt("The voltage: ");
            int ageMonths = readInt("The accumulator age in months: ");
            try {
                return new Accumulator(capacityAh,voltage,ageMonths);
            } catch (UnrealisticException e){
                System.out.println("Invalid accumulator: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for amortization properties (shock type, wear and
     * adjustability) and returns a valid {@link Amortization}, looping until
     * the input passes validation.
     *
     * @return a newly constructed amortization unit
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Amortization createAmortization() throws UnrealisticException{
        while (true){
            String answer = readChoice(
                    "Choose one of the following shock types: \n1: (G)as\n2: (H)ydraulic\n3: (A)ir",
                    "1","G","2","H","3","A");

            int wearPercentage = readInt("The wear percentage: ");
            boolean adjustable = readYesNo("Is it adjustable?");

            Amortization.ShockType shock;
            switch (answer){
                case "1","G":
                    shock = Amortization.ShockType.GAS;
                    break;
                case "2","H":
                    shock = Amortization.ShockType.HYDRAULIC;
                    break;
                default:
                    shock = Amortization.ShockType.AIR;
            }
            try {
                return new Amortization(shock,wearPercentage,adjustable);
            } catch (UnrealisticException e){
                System.out.println("Invalid amortization: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for brake-pad properties (wear, ABS support, material)
     * and returns a valid {@link BrakePads}, looping until the input passes
     * validation.
     *
     * @return a newly constructed brake pad set
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public BrakePads createBrakePads() throws UnrealisticException {
        while (true){
            int wearPercentage = readInt("What is the wear in percentage?");
            boolean isABSEnabled = readYesNo("Is ABS enabled?");
            String choice = readChoice(
                    "Choose one of the following materials\n1: (C)eramic\n2: (M)etallic\n3: (O)rganic",
                    "1","C","2","M","3","O");

            BrakePads.Material mat;
            switch (choice){
                case "1","C":
                    mat = BrakePads.Material.CERAMIC;
                    break;
                case "2","M":
                    mat = BrakePads.Material.METALLIC;
                    break;
                default:
                    mat = BrakePads.Material.ORGANIC;
            }
            try {
                return new BrakePads(mat,wearPercentage,isABSEnabled);
            } catch (UnrealisticException e){
                System.out.println("Invalid brake pads: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for the bumper material and returns a front
     * {@link Bumper} with parking sensors disabled.
     *
     * @return the newly constructed front bumper
     */
    public Bumper createFrontBumper(){
        String answer = readChoice(
                "Choose the bumper material.\n1: (P)lastic\n2: (C)arbon\n3: (S)teel",
                "1","P","2","C","3","S");

        switch (answer){
            case "1","P":
                return new Bumper(Bumper.Position.FRONT,Bumper.Material.PLASTIC,false);
            case "2","C":
                return new Bumper(Bumper.Position.FRONT,Bumper.Material.CARBON,false);
            default:
                return new Bumper(Bumper.Position.FRONT,Bumper.Material.STEEL,false);
        }
    }

    /**
     * Prompts the user for the bumper material and whether parking sensors
     * are present, then returns the corresponding rear {@link Bumper}.
     *
     * @return the newly constructed rear bumper
     */
    public Bumper createRearBumper(){
        String answer = readChoice(
                "Choose the bumper material.\n1: (P)lastic\n2: (C)arbon\n3: (S)teel",
                "1","P","2","C","3","S");

        boolean hasParkingSensor = readYesNo("Does it have a parking sensors?");

        switch (answer){
            case "1","P":
                return new Bumper(Bumper.Position.REAR,Bumper.Material.PLASTIC,hasParkingSensor);
            case "2","C":
                return new Bumper(Bumper.Position.REAR,Bumper.Material.CARBON,hasParkingSensor);
            default:
                return new Bumper(Bumper.Position.REAR,Bumper.Material.STEEL,hasParkingSensor);
        }
    }

    /**
     * Prompts the user for engine properties (fuel type, horsepower, cylinder
     * count, turbocharger) and returns a valid {@link Engine}, looping until
     * the input passes validation.
     *
     * @return a newly constructed engine
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Engine createEngine() throws UnrealisticException{
        while (true){
            String answer = readChoice(
                    "Choose on of the following fuel types\n1: (P)etrol\n2: (D)iesel\n3: (E)lectric\n4: (H)ybrid",
                    "1","P","2","D","3","E","4","H");

            int hp = readInt("Horse powers: ");
            int cc = readInt("Cylinder count: ");
            boolean isTurbocharged = readYesNo("Is it turbocharged?");

            Engine.FuelType ft;
            switch (answer){
                case "1","P":
                    ft = Engine.FuelType.PETROL;
                    break;
                case "2","D":
                    ft = Engine.FuelType.DIESEL;
                    break;
                case "3","E":
                    ft = Engine.FuelType.ELECTRIC;
                    break;
                default:
                    ft = Engine.FuelType.HYBRID;
            }
            try {
                return new Engine(hp, ft, cc, isTurbocharged);
            } catch (UnrealisticException e){
                System.out.println("Invalid engine: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for whether the drivetrain is all-wheel-drive and the
     * transmission type, and returns the corresponding {@link Gearbox}.
     *
     * @return the newly constructed gearbox
     */
    public Gearbox createGearbox(){
        boolean isAWD = readYesNo("Is it AWD?");

        String answer = readChoice(
                "Choose transmission type\n1: (M)anual\n2: (A)utomatic",
                "1","M","2","A");

        switch (answer){
            case "1","M":
                return new Gearbox(Gearbox.TransmissionType.MANUAL,isAWD);
            default:
                return new Gearbox(Gearbox.TransmissionType.AUTOMATIC,isAWD);
        }
    }

    /**
     * Prompts the user for every brand attribute, including any number of
     * service locations, and returns a valid {@link Brand}. Loops until the
     * supplied data passes validation.
     *
     * @return a newly constructed brand
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Brand createBrand() throws UnrealisticException {
        while (true){
            System.out.println("The brand name: ");
            String name = sc.nextLine();

            System.out.println("The phone number: ");
            String phoneNumber = sc.nextLine();

            System.out.println("The email: ");
            String email = sc.nextLine();

            System.out.println("The website: ");
            String website = sc.nextLine();

            System.out.println("The country of origin: ");
            String country = sc.nextLine();

            boolean isLuxury = readYesNo("Is it a luxury brand?");

            int foundedYear = readInt("The founded year: ");

            int locationCount = readInt("How many service locations?");
            while (locationCount < 0){
                System.out.println("Service location count cannot be negative. Please try again.");
                locationCount = readInt("How many service locations?");
            }

            Brand.Location[] serviceLocations = new Brand.Location[locationCount];
            for (int i = 0; i < locationCount; i++){
                System.out.println("Location " + (i + 1) + " city: ");
                String city = sc.nextLine();

                System.out.println("Location " + (i + 1) + " country: ");
                String locationCountry = sc.nextLine();

                System.out.println("Location " + (i + 1) + " address: ");
                String address = sc.nextLine();

                serviceLocations[i] = new Brand.Location(city,locationCountry,address);
            }

            try {
                return new Brand(name,phoneNumber,email,website,country,serviceLocations,isLuxury,foundedYear);
            } catch (UnrealisticException e){
                System.out.println("Invalid brand: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for whether the side mirror has camera assist and
     * returns the corresponding {@link SideMirror}.
     *
     * @return the newly constructed side mirror
     */
    public SideMirror createSideMirror(){
        boolean hasCameraAssist = readYesNo("Does it have camera assist?");
        SideMirror leftMirror = new SideMirror(SideMirror.Side.LEFT, hasCameraAssist);
        SideMirror rightMirror = new SideMirror(SideMirror.Side.RIGHT, hasCameraAssist);
        return leftMirror;
    }

    /**
     * Prompts the user for windscreen options (heating, rain sensor, HUD) and
     * returns the corresponding {@link Windscreen}.
     *
     * @return the newly constructed windscreen
     */
    public Windscreen createWindscreen(){
        boolean isHeated = readYesNo("Is it heated?");
        boolean hasRainSensor = readYesNo("Does it have a rain sensor?");
        boolean hasHUD = readYesNo("Does it have HUD?");

        return new Windscreen(isHeated,hasRainSensor,hasHUD);
    }

    /**
     * Prompts the user for light technology, adaptive support and daytime
     * running configuration, and returns the corresponding {@link Lights}.
     *
     * @return the newly constructed lights assembly
     */
    public Lights createLights(){
        String answer = readChoice(
                "Choose one of the following light types: \n1: (H)alogen\n2: (L)ED\n3: (X)enon\n4: (LA)ser",
                "1","H","2","L","3","X","4","LA");

        boolean isAdaptive = readYesNo("Is it adaptive?");
        boolean hasDaytimeRunning = readYesNo("Does it have daytime running?");

        switch (answer){
            case "1","H":
                return new Lights(Lights.LightType.HALOGEN,isAdaptive,hasDaytimeRunning);
            case "2","L":
                return new Lights(Lights.LightType.LED,isAdaptive,hasDaytimeRunning);
            case "3","X":
                return new Lights(Lights.LightType.XENON,isAdaptive,hasDaytimeRunning);
            default:
                return new Lights(Lights.LightType.LASER,isAdaptive,hasDaytimeRunning);
        }
    }

    /**
     * Prompts the user for the rim diameter and seasonal type and returns a
     * valid {@link Tires} instance, looping until the input passes validation.
     *
     * @return the newly constructed tires
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Tires createTires() throws UnrealisticException{
        while (true){
            int rimDiameterInch = readInt("The rim diameter in inches: ");
            String answer = readChoice(
                    "Choose one of the following seasons: \n1: (S)ummer\n2: (W)inter\n3: (A)ll season",
                    "1","S","2","W","3","A");

            Tires.Season season;
            switch (answer){
                case "1","S":
                    season = Tires.Season.SUMMER;
                    break;
                case "2","W":
                    season = Tires.Season.WINTER;
                    break;
                default:
                    season = Tires.Season.ALL_SEASON;
            }
            try {
                return new Tires(rimDiameterInch,season);
            } catch (UnrealisticException e){
                System.out.println("Invalid tires: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Prompts the user for rim diameter, spoke count and material, and
     * returns a valid {@link Rims} instance, looping until the input passes
     * validation.
     *
     * @return the newly constructed rims
     * @throws UnrealisticException never thrown by the loop, kept on the
     *                              signature for symmetry with the domain API
     */
    public Rims createRims() throws UnrealisticException{
        while (true){
            int diameterInch = readInt("The rim diameter in inches: ");
            int spokeCount = readInt("The spoke count: ");
            String answer = readChoice(
                    "Choose one of the following materials: \n1: (A)lloy\n2: (S)teel\n3: (C)arbon",
                    "1","A","2","S","3","C");

            Rims.Material mat;
            switch (answer){
                case "1","A":
                    mat = Rims.Material.ALLOY;
                    break;
                case "2","S":
                    mat = Rims.Material.STEEL;
                    break;
                default:
                    mat = Rims.Material.CARBON;
            }
            try {
                return new Rims(diameterInch,mat,spokeCount);
            } catch (UnrealisticException e){
                System.out.println("Invalid rims: " + e.getMessage() + ". Please try again.");
            }
        }
    }

    /**
     * Creates a starter {@link Wallet} pre-funded with $1000 and notifies the
     * user of the initial balance.
     *
     * @return a new wallet seeded with the initial amount
     */
    public Wallet createWallet(){
        System.out.println("your initial amount is $1000");
        return new Wallet(new Money(1000.0));
    }

    /**
     * Reads an integer from the user, re-prompting on non-numeric input.
     *
     * @param prompt the message printed before each read attempt
     * @return the integer entered by the user
     */
    private int readInt(String prompt){
        while (true){
            System.out.println(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e){
                System.out.println("Invalid integer. Please try again.");
            }
        }
    }

    /**
     * Reads a double-precision floating point number from the user,
     * re-prompting on non-numeric input.
     *
     * @param prompt the message printed before each read attempt
     * @return the value entered by the user
     */
    private double readDouble(String prompt){
        while (true){
            System.out.println(prompt);
            String line = sc.nextLine().trim();
            try {
                return Double.parseDouble(line);
            } catch (NumberFormatException e){
                System.out.println("Invalid number. Please try again.");
            }
        }
    }

    /**
     * Reads a Yes/No answer from the user, accepting {@code Y}, {@code YES},
     * {@code N} or {@code NO} (case-insensitive). Re-prompts on any other
     * input.
     *
     * @param prompt the question presented to the user
     * @return {@code true} for an affirmative answer; {@code false} for a
     *         negative answer
     */
    private boolean readYesNo(String prompt){
        while (true){
            System.out.println(prompt + " (Y/N)");
            String line = sc.nextLine().trim().toUpperCase();
            switch (line){
                case "Y","YES":
                    return true;
                case "N","NO":
                    return false;
            }
            System.out.println("Invalid answer. Please enter Y or N.");
        }
    }

    /**
     * Reads a discrete choice from the user, comparing the (uppercased)
     * input against the supplied valid options. Re-prompts on any
     * unrecognised value.
     *
     * @param prompt       the menu printed before each read attempt
     * @param validOptions the accepted answers (compared case-insensitively)
     * @return the matched option in upper case
     */
    private String readChoice(String prompt, String... validOptions){
        while (true){
            System.out.println(prompt);
            String line = sc.nextLine().trim().toUpperCase();
            for (String opt : validOptions){
                if (line.equals(opt)) return line;
            }
            System.out.println("Invalid option. Please try again.");
        }
    }
}
