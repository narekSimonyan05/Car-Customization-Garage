package am.aua.garage.cli;

import am.aua.garage.core.*;
import am.aua.garage.core.parts.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;
import am.aua.garage.utils.FileUtils;

import java.io.IOException;
import java.util.Scanner;

/**
 * Entry point for the text-based interface to the {@link Garage}.
 * <p>
 * The console drives a menu loop that lets the user add and remove vehicles,
 * upgrade or repair parts, deposit funds, inspect the garage and persist or
 * restore its state via {@link FileUtils}. Most actual user input is delegated
 * to a {@link VehicleBuilder}.
 * <p>
 * Although every member is {@code static}, this class is not intended to be
 * instantiated &mdash; call {@link #start()} to begin a session.
 */
public class GarageConsole {
    /** Shared scanner bound to {@code System.in} for the duration of the session. */
    public static Scanner sc = null;
    /** The garage being managed in the current session. */
    public static Garage garage = null;
    /** Helper that prompts the user for vehicle and part properties. */
    public static VehicleBuilder builder = null;

    /**
     * Initialises the session and runs the main menu loop until the user
     * chooses to quit. Prints a welcome banner on entry and a farewell on
     * exit.
     */
    public static void start(){
        sc = new Scanner(System.in);
        builder = new VehicleBuilder(sc);
        garage = new Garage(builder.createWallet());

        System.out.println();
        System.out.println("====================================");
        System.out.println("    Welcome to your Garage!");
        System.out.println("====================================");

        mainLoop:
        do{
            System.out.println();
            System.out.println("--- Menu ---");
            printOptions();
            System.out.print("> ");
            String choice = sc.nextLine();

            switch (choice){
                case "1","A":
                    addVehicle();
                    break;
                case "2","U":
                    upgradeVehicle();
                    break;
                case "3","R":
                    repairVehicle();
                    break;
                case "4","M":
                    makeDeposit();
                    break;
                case "5","C":
                    checkBalance();
                    break;
                case "6","P":
                    printVehicleDetails();
                    break;
                case "7","T":
                    takeVehicleOut();
                    break ;
                case "8","S":
                    saveToFile();
                    break;
                case "9","L":
                    loadFromFile();
                    break;
                case "10","Q":
                    break mainLoop;
                default:
                    printOptions();
                    System.out.println("Invalid option, please try again.");
            }
        }while (true);

        System.out.println();
        System.out.println("Thank you for using the Garage. Goodbye!");
    }

    /**
     * Prints the main menu options to {@code System.out}.
     */
    private static void printOptions(){
        System.out.println("1: (A)dd vehicle.");
        System.out.println("2: (U)pgrade vehicle.");
        System.out.println("3: (R)epair vehicle.");
        System.out.println("4: (M)ake a deposit.");
        System.out.println("5: (C)heck balance.");
        System.out.println("6: (P)rint vehicle details.");
        System.out.println("7: (T)ake vehicle out of the garage.");
        System.out.println("8: (S)ave to file.");
        System.out.println("9: (L)oad from file.");
        System.out.println("10: (Q)uit.");
    }

    /**
     * Prints the list of upgradable parts to {@code System.out}.
     */
    private static void printPartOptions(){
        System.out.println("1: Accumulator");
        System.out.println("2: Amortization");
        System.out.println("3: Brake pads");
        System.out.println("4: Bumper");
        System.out.println("5: Engine");
        System.out.println("6: Gearbox");
        System.out.println("7: Lights");
        System.out.println("8: Rims");
        System.out.println("9: Side mirror");
        System.out.println("10: Tires");
        System.out.println("11: Windscreen");
    }

    /**
     * Builds a new vehicle through the {@link #builder} and adds it to the
     * garage, refusing if the garage is at capacity. Reports the outcome to
     * the user.
     */
    private static void addVehicle(){
        if (garage.getVehicleCount() >= garage.getMaxCapacity()){
            System.out.println("The garage is full. Cannot add more vehicles.");
            return;
        }
        try {
            Vehicle v = builder.createVehicle();
            if (v == null){
                System.out.println("Vehicle creation failed.");
                return;
            }
            if (garage.addNewVehicle(v)){
                System.out.println("Vehicle added successfully.");
            } else {
                System.out.println("Could not add the vehicle.");
            }
        } catch (UnrealisticException e){
            System.out.println("Invalid input: " + e.getMessage());
        }
    }

    /**
     * Prompts the user to pick a vehicle and removes it from the garage.
     * Returns silently if the garage is empty.
     */
    private static void takeVehicleOut(){
               int idx = chooseVehicleIndex();

        while (idx < 0){
            if (garage.getVehicleCount() == 0){
                return;
            }
            sc.nextLine();
            idx = chooseVehicleIndex();
        }

        garage.removeVehicle(idx);
    }

    /**
     * Asks the user for a destination path (or empty for the default) and
     * persists the current garage to disk through {@link FileUtils}.
     */
    private static void saveToFile(){
        System.out.print("Enter file path (leave empty for default): ");
        String path = sc.nextLine().trim();
        try {
            if (path.isEmpty()){
                FileUtils.saveGarage(garage.getStorageString());
            } else {
                FileUtils.saveGarage(garage.getStorageString(), path);
            }
            System.out.println("Garage saved successfully.");
        } catch (IOException e){
            System.out.println("Failed to save garage: " + e.getMessage());
        }
    }

    /**
     * Asks the user for a source path (or empty for the default) and replaces
     * the in-memory garage with the one loaded from disk. Prints the loaded
     * garage on success and an explanatory message on failure.
     */
    private static void loadFromFile(){
        System.out.print("Enter file path (leave empty for default): ");
        String path = sc.nextLine().trim();
        Garage loaded;
        try {
            if (path.isEmpty()){
                loaded = FileUtils.loadGarage();
            } else {
                loaded = FileUtils.loadGarage(path);
            }
        } catch (IOException e){
            System.out.println("Failed to load garage: " + e.getMessage());
            return;
        }
        if (loaded == null){
            System.out.println("Failed to load garage. The file may be missing or corrupted.");
            return;
        }
        garage = loaded;
        System.out.println("Garage loaded successfully.");
        System.out.println(garage);
    }

    /** Predefined accumulator variation labels available for upgrade. */
    private static final String[] ACCUMULATOR_OPTIONS = {
            "AgedNeedsReplacementBattery",
            "CityCarLightBattery",
            "HeavyDutyCommercialBattery",
            "HighCapacityNearNewBattery",
            "MidLargeFreshBattery",
            "MidsizeAgingBattery",
            "StandardSedanBattery"
    };
    /** Predefined amortization variation labels available for upgrade. */
    private static final String[] AMORTIZATION_OPTIONS = {
            "AirShockAdjustable",
            "AirShockBrandNewAdjustable",
            "AirShockFixed",
            "GasShockAdjustable",
            "GasShockFixed",
            "GasShockLowWearFixed",
            "HydraulicShockAdjustable",
            "HydraulicShockFixed",
            "HydraulicShockNearNewAdjustable"
    };
    /** Predefined brake-pad variation labels available for upgrade. */
    private static final String[] BRAKEPADS_OPTIONS = {
            "CeramicNearNewWithABS",
            "CeramicNoABS",
            "CeramicWithABS",
            "MetallicLowWearWithABS",
            "MetallicNoABS",
            "MetallicWithABS",
            "OrganicMidWearNoABS",
            "OrganicNoABS",
            "OrganicWithABS"
    };
    /** Predefined bumper variation labels available for upgrade. */
    private static final String[] BUMPER_OPTIONS = {
            "FrontCarbonLuxuryWithSensor",
            "FrontCarbonRacing",
            "FrontPlasticBudget",
            "FrontSteelHeavyDuty",
            "RearCarbonSport",
            "RearPlasticBudget",
            "RearSteelTowingReady"
    };
    /** Predefined engine variation labels available for upgrade. */
    private static final String[] ENGINE_OPTIONS = {
            "DieselEconomyNaturallyAspirated",
            "DieselHeavyDutyTurbo",
            "DieselSportSUVTurbo",
            "ElectricCityCommuter",
            "ElectricHighPerformance",
            "HybridEcoCommuter",
            "HybridMidPerformanceTurbo",
            "HybridSportPerformance",
            "PetrolEconomyNaturallyAspirated",
            "PetrolPerformanceTurbo",
            "PetrolStandardSedanNaturallyAspirated"
    };
    /** Predefined gearbox variation labels available for upgrade. */
    private static final String[] GEARBOX_OPTIONS = {
            "AutomaticAllWheelDrive",
            "AutomaticTwoWheelDrive",
            "ManualAllWheelDrive",
            "ManualTwoWheelDrive"
    };
    /** Predefined light variation labels available for upgrade. */
    private static final String[] LIGHTS_OPTIONS = {
            "HalogenStaticBasic",
            "HalogenStaticWithDRL",
            "LaserAdaptiveLuxury",
            "LaserStaticPerformance",
            "LedAdaptiveModern",
            "LedStaticEconomy",
            "XenonAdaptivePremium",
            "XenonAdaptiveSportNoDRL",
            "XenonStaticBasic"
    };
    /** Predefined rim variation labels available for upgrade. */
    private static final String[] RIMS_OPTIONS = {
            "AlloySportPerformance19inch7spoke",
            "AlloyStandardSedan17inch5spoke",
            "CarbonLuxuryShowcar22inch8spoke",
            "CarbonRacing20inch5spoke",
            "CarbonSport19inch7spoke",
            "SteelCompactCar16inch5spoke",
            "SteelEconomy15inch5spoke",
            "SteelTruck17inch6spoke"
    };
    /** Predefined side-mirror variation labels available for upgrade. */
    private static final String[] SIDEMIRROR_OPTIONS = {
            "LeftBasicNoCamera",
            "LeftPremiumWithCamera",
            "RightBasicNoCamera",
            "RightPremiumWithCamera"
    };
    /** Predefined tire variation labels available for upgrade. */
    private static final String[] TIRES_OPTIONS = {
            "AllSeasonLargeSUV20inch",
            "AllSeasonMidSUV18inch",
            "AllSeasonStandardSedan17inch",
            "SummerCity15inch",
            "SummerCompactCar16inch",
            "SummerSport19inch",
            "WinterCityCommuter15inch",
            "WinterPerformance18inch",
            "WinterStandardSedan17inch"
    };
    /** Predefined windscreen variation labels available for upgrade. */
    private static final String[] WINDSCREEN_OPTIONS = {
            "BasicNoFeatures",
            "HeatedOnly",
            "HeatedWithHud",
            "HeatedWithRainSensor",
            "HudOnly",
            "PremiumAllFeatures",
            "RainSensorOnly",
            "RainSensorWithHud"
    };

    /**
     * Drives the upgrade flow: pick a vehicle, pick a part, pick a predefined
     * variation, confirm the cost and apply the change. Errors during parsing
     * or charging are reported back to the user without aborting the session.
     */
    private static void upgradeVehicle(){
        int idx = chooseVehicleIndex();
        while (idx < 0){
            if (garage.getVehicleCount() == 0){
                return;
            }
            sc.nextLine();
            idx = chooseVehicleIndex();
        }
        Vehicle v = garage.getVehicle(idx);

        System.out.println("Which part would you like to upgrade?");
        printPartOptions();
        System.out.print("> ");
        String choice = sc.nextLine().trim().toUpperCase();

        try {
            switch (choice){
                case "1":{
                    String content = FileUtils.pickAndLoadPart(sc,ACCUMULATOR_OPTIONS, "Accumulator");
                    if (content == null) return;
                    Accumulator part = new Accumulator(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeAccumulator(part);
                    break;
                }
                case "2": {
                    String content = FileUtils.pickAndLoadPart(sc,AMORTIZATION_OPTIONS, "Amortization");
                    if (content == null) return;
                    Amortization part = new Amortization(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeAmortization(part);
                    break;
                }
                case "3": {
                    String content = FileUtils.pickAndLoadPart(sc,BRAKEPADS_OPTIONS, "Brake pads");
                    if (content == null) return;
                    BrakePads part = new BrakePads(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeBrakePads(part);
                    break;
                }
                case "4": {
                    String content = FileUtils.pickAndLoadPart(sc,BUMPER_OPTIONS, "Bumper");
                    if (content == null) return;
                    Bumper part = new Bumper(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeBumper(part);
                    break;
                }
                case "5": {
                    String content = FileUtils.pickAndLoadPart(sc,ENGINE_OPTIONS, "Engine");
                    if (content == null) return;
                    Engine part = new Engine(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeEngine(part);
                    break;
                }
                case "6": {
                    String content = FileUtils.pickAndLoadPart(sc,GEARBOX_OPTIONS, "Gearbox");
                    if (content == null) return;
                    Gearbox part = new Gearbox(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeGearbox(part);
                    break;
                }
                case "7": {
                    String content = FileUtils.pickAndLoadPart(sc,LIGHTS_OPTIONS, "Lights");
                    if (content == null) return;
                    Lights part = new Lights(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeLights(part);
                    break;
                }
                case "8": {
                    String content = FileUtils.pickAndLoadPart(sc,RIMS_OPTIONS, "Rims");
                    if (content == null) return;
                    Rims part = new Rims(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeRims(part);
                    break;
                }
                case "9": {
                    String content = FileUtils.pickAndLoadPart(sc,SIDEMIRROR_OPTIONS, "Side mirror");
                    if (content == null) return;
                    SideMirror part = new SideMirror(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeSideMirrors(part);
                    break;
                }
                case "10": {
                    String content = FileUtils.pickAndLoadPart(sc,TIRES_OPTIONS, "Tires");
                    if (content == null) return;
                    Tires part = new Tires(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeTires(part);
                    break;
                }
                case "11": {
                    String content = FileUtils.pickAndLoadPart(sc,WINDSCREEN_OPTIONS, "Windscreen");
                    if (content == null) return;
                    Windscreen part = new Windscreen(content);
                    if (!confirmAndCharge(part.calculateRepairCost())) return;
                    v.changeWindScreen(part);
                    break;
                }
                default:
                    System.out.println("Invalid part choice.");
                    return;
            }
            System.out.println("Part upgraded successfully. Remaining balance: " + garage.getWallet().getBalance());
        } catch (Exception e){
            System.out.println("Invalid input: " + e.getMessage());
        }
    }

    /**
     * Shows the supplied cost and current balance to the user, asks for
     * confirmation, and charges the wallet on agreement.
     *
     * @param cost the price to confirm and deduct
     * @return {@code true} if the user confirmed and the wallet was
     *         successfully charged; {@code false} if the user declined or had
     *         insufficient funds
     */
    private static boolean confirmAndCharge(Money cost){
        System.out.println("Upgrade cost:    " + cost);
        System.out.println("Current balance: " + garage.getWallet().getBalance());
        System.out.print("Proceed? (Y/N): ");
        String confirm = sc.nextLine().trim().toUpperCase();

        if (!confirm.equals("Y") && !confirm.equals("YES")){
            System.out.println("Upgrade cancelled.");
            return false;
        }
        if (!garage.charge(cost)){
            System.out.println("Insufficient funds.");
            return false;
        }
        return true;
    }

    /**
     * Lists the vehicles in the garage and prompts the user to pick one by
     * number.
     *
     * @return the zero-based index of the chosen vehicle, or {@code -1} if
     *         the garage is empty or the user entered an invalid number
     */
    private static int chooseVehicleIndex(){
        Vehicle[] vehicles = garage.getVehicles();
        if (vehicles == null || vehicles.length == 0){
            System.out.println("There are no vehicles in the garage.");
            return -1;
        }
        System.out.println("Select a vehicle :");
        for (int i = 0; i < vehicles.length; i++){
            System.out.println((i + 1) + ": " + vehicles[i].getBrand().getName() + " ("
                    + vehicles[i] + ")");
        }
        int input = readInt("> ");
        int idx = input - 1;
        if (idx < 0 || idx >= vehicles.length){
            System.out.println("Invalid vehicle number.");
            return -1;
        }
        return idx;
    }

    /**
     * Drives the repair flow: pick a vehicle, display the estimated cost and
     * current balance, and on user confirmation withdraw the cost from the
     * wallet. Aborts gracefully if funds are insufficient.
     */
    private static void repairVehicle(){
        Vehicle v = chooseVehicle();
        if (v == null) return;

        Money cost = v.calculateRepairCost();
        Wallet wallet = garage.getWallet();
        System.out.println("Estimated repair cost: " + cost);
        System.out.println("Current balance:       " + wallet.getBalance());
        System.out.print("Proceed with repair? (Y/N): ");
        String confirm = sc.nextLine().trim().toUpperCase();

        if (!confirm.equals("Y") && !confirm.equals("YES")){
            System.out.println("Repair cancelled.");
            return;
        }

        if (wallet.getBalance().compareTo(cost) < 0){
            System.out.println("Insufficient funds. Please make a deposit first.");
            return;
        }
        wallet.withdraw(cost);
        System.out.println("Repair complete.");
        System.out.println("Remaining balance: " + wallet.getBalance());
    }

    /**
     * Prompts the user for a positive amount and deposits it into the
     * garage wallet. Reports the new balance on success and an error on
     * non-numeric or non-positive input.
     */
    private static void makeDeposit(){
        System.out.print("Enter deposit amount: $");
        try {
            double amount = Double.parseDouble(sc.nextLine().trim());
            if (amount <= 0){
                System.out.println("Deposit amount must be positive.");
                return;
            }
            garage.getWallet().deposit(new Money(amount));
            System.out.println("Deposit successful. New balance: " + garage.getWallet().getBalance());
        } catch (NumberFormatException e){
            System.out.println("Invalid amount.");
        }
    }

    /**
     * Prints the current wallet balance to {@code System.out}.
     */
    private static void checkBalance(){
        System.out.println("Current balance: " + garage.getWallet().getBalance());
    }

    /**
     * Lets the user print either every vehicle or a single chosen vehicle.
     * Returns silently when the garage is empty.
     */
    private static void printVehicleDetails(){
        if (garage.getVehicleCount() == 0){
            System.out.println("The garage is empty.");
            return;
        }
        System.out.println();
        System.out.println("Print options:");
        System.out.println("1: (A)ll vehicles");
        System.out.println("2: (O)ne specific vehicle");
        System.out.print("> ");
        String choice = sc.nextLine().trim().toUpperCase();
        if (choice.equals("1") || choice.equals("A")){
            Vehicle[] vehicles = garage.getVehicles();
            System.out.println();
            for (int i = 0; i < vehicles.length; i++){
                System.out.println("--- Vehicle " + (i + 1) + " ---");
                System.out.println(vehicles[i]);
                System.out.println();
            }
            return;
        }
        if (choice.equals("2") || choice.equals("O")){
            int input = readInt("Enter the vehicle index: ");
            int idx = input - 1;
            if (idx < 0 || idx >= garage.getVehicleCount()){
                System.out.println("Invalid vehicle number.");
                return;
            }
            System.out.println();
            System.out.println(garage.getVehicle(idx));
            return;
        }
        System.out.println("Invalid option.");
    }

    /**
     * Lists the vehicles in the garage and prompts the user to pick one by
     * number.
     *
     * @return the chosen {@link Vehicle}, or {@code null} if the garage is
     *         empty or the user entered an invalid number
     */
    private static Vehicle chooseVehicle(){
        Vehicle[] vehicles = garage.getVehicles();
        if (vehicles == null || vehicles.length == 0){
            System.out.println("There are no vehicles in the garage.");
            return null;
        }
        System.out.println("Select a vehicle :");
        for (int i = 0; i < vehicles.length; i++){
            System.out.println((i + 1) + ": " + vehicles[i].getBrand().getName() + " ("
                    + vehicles[i] + ")");
        }
        int input = readInt("> ");

        int idx = input - 1;

        if (idx < 0 || idx >= vehicles.length){
            System.out.println("Invalid vehicle number.");
            return null;
        }
        return vehicles[idx];

    }

    /**
     * Reads an integer from the shared {@link #sc scanner}, re-prompting
     * until a valid integer is entered.
     *
     * @param prompt the message printed before each read attempt
     * @return the integer entered by the user
     */
    private static int readInt(String prompt){
        while (true){
            System.out.println(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e){
                System.out.println("Invalid integer. Please try again.");
            }
        }
    }
}