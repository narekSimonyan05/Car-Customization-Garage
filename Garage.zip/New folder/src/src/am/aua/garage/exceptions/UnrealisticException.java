package am.aua.garage.exceptions;

/**
 * Thrown when a value passed to a domain object falls outside the realistic
 * range it accepts (e.g. negative wear, over-the-top horsepower).
 */
public class UnrealisticException extends Exception {

    /**
     * Creates the exception with a default message.
     */
    public UnrealisticException() {
        this("Unreal action!");
    }

    /**
     * Creates the exception with a custom message.
     *
     * @param s a description of why the value is unrealistic
     */
    public UnrealisticException(String s) {
        super(s);
    }
}
