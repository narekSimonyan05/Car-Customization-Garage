package am.aua.garage.exceptions;

/**
 * Thrown when a storage string passed to a {@code (String)} constructor is
 * missing fields, has the wrong tag, or contains values that can't be parsed.
 */
public class MalformedStringException extends Exception {

    /**
     * Creates the exception with a default message.
     */
    public MalformedStringException() {
        this("Malformed storage string.");
    }

    /**
     * Creates the exception with a custom message.
     *
     * @param s a description of what's wrong with the string
     */
    public MalformedStringException(String s) {
        super(s);
    }
}
