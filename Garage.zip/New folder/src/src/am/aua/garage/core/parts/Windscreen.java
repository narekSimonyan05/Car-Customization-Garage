package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;

/**
 * The windscreen (front windshield). Repair cost is a base price plus extras
 * for heating, rain sensor, and a head-up display.
 */
public class Windscreen implements Repairable, Cloneable {
    private boolean isHeated;
    private boolean hasRainSensor;
    private boolean hasHUD;
    private String DELIMITER = "%%";

    /**
     * @param isHeated      whether the windscreen has built-in heating
     * @param hasRainSensor whether it triggers wipers automatically in rain
     * @param hasHUD        whether it projects a head-up display
     */
    public Windscreen(boolean isHeated, boolean hasRainSensor, boolean hasHUD) {
        this.isHeated = isHeated;
        this.hasRainSensor = hasRainSensor;
        this.hasHUD = hasHUD;
    }

    /**
     * Reconstructs a windscreen from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Windscreen(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("Windscreen"))
            throw new MalformedStringException("Invalid string for Windscreen.");
        this.isHeated = Boolean.parseBoolean(parts[1]);
        this.hasRainSensor = Boolean.parseBoolean(parts[2]);
        this.hasHUD = Boolean.parseBoolean(parts[3]);
    }

    /** @return a string that can later be passed to {@link #Windscreen(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + isHeated + DELIMITER + hasRainSensor + DELIMITER + hasHUD;
    }

    /** @return base cost plus surcharges for heating, rain sensor, and HUD */
    public Money calculateRepairCost() {

        long cost = 250;

        if (isHeated) cost += 200;
        if (hasRainSensor) cost += 80;
        if (hasHUD) cost += 350;

        return new Money(cost);
    }

    /** @return a human-readable description of the windscreen */
    public String toString(){
        return (isHeated?"Heated ":"") + "windscreen " + (hasRainSensor?" with rain sensors":" without rain sensors")
                + (hasHUD?" and with HUD.":".");
    }

    /** @return a deep copy of this windscreen */
    public Windscreen clone() {
        try {
            return (Windscreen) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
