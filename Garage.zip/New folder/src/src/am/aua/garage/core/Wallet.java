package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;

/**
 * A wallet holding a single {@link Money} balance. Wraps deposit/withdraw
 * operations and supports cloning and comparison by balance.
 */
public class Wallet implements Cloneable, Comparable<Wallet> {

    private Money balance;
    private String DELIMITER = "%%";

    /**
     * Creates an empty wallet ($0.00).
     */
    public Wallet() {
        this.balance = new Money(0);
    }

    /**
     * @param initialAmount the starting balance
     */
    public Wallet(Money initialAmount) {
        this.balance = initialAmount;
    }

    /**
     * Reconstructs a wallet from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Wallet(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 3 || !parts[0].equals("Wallet"))
            throw new MalformedStringException("Invalid string for Wallet.");
        this.balance = new Money(parts[1] + "%%" + parts[2]);
    }

    /** @return a string that can later be passed to {@link #Wallet(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + balance.getStorageString();
    }

    /**
     * Adds {@code amount} to the balance.
     *
     * @param amount the amount to deposit
     */
    public void deposit(Money amount) {
        this.balance.add(amount);
    }

    /**
     * Subtracts {@code amount} from the balance. No-ops if the wallet is short.
     *
     * @param amount the amount to withdraw
     */
    public void withdraw(Money amount) {
        this.balance.subtract(amount);
    }

    /** @return the current balance (live reference, not a copy) */
    public Money getBalance() {
        return balance;
    }

    /** @return a printable description like {@code Wallet Balance: $X.YZ} */
    public String toString() {
        return "Wallet Balance: " + balance;
    }

    /**
     * Compares two wallets by their balance.
     *
     * @param other the other wallet
     * @return negative, zero, or positive following {@link Comparable} contract
     */
    public int compareTo(Wallet other){
        return balance.compareTo(other.balance);
    }

    /** @return a deep copy of this wallet (the {@link Money} is duplicated) */
    public Wallet clone() {
        try {
            Wallet copy = (Wallet) super.clone();
            copy.balance = new Money(this.balance.getCents());
            return copy;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
