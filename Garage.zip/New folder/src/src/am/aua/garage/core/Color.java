package am.aua.garage.core;

/**
 * Enumerates the colors a {@link Vehicle} can be painted in.
 */
public enum Color {
    /** Black paint. */
    BLACK,
    /** White paint. */
    WHITE,
    /** Green paint. */
    GREEN,
    /** Blue paint. */
    BLUE,
    /** Red paint. */
    RED
}
