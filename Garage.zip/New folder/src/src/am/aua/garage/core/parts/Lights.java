package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;

/**
 * Headlight assembly. Repair cost depends on bulb technology, adaptive
 * steering support, and daytime running lights.
 */
public class Lights implements Repairable, Cloneable {

    /** Bulb technology. */
    public enum LightType {
        /** Halogen (cheap, classic). */ HALOGEN,
        /** LED. */ LED,
        /** Xenon HID. */ XENON,
        /** Laser (premium). */ LASER
    }

    private LightType type;
    private boolean isAdaptive;
    private boolean hasDaytimeRunning;
    private String DELIMITER = "%%";

    /**
     * @param type              bulb technology
     * @param isAdaptive        whether headlights swivel with steering
     * @param hasDaytimeRunning whether DRLs are present
     */
    public Lights(LightType type, boolean isAdaptive, boolean hasDaytimeRunning) {
        this.type = type;
        this.isAdaptive = isAdaptive;
        this.hasDaytimeRunning = hasDaytimeRunning;
    }

    /**
     * Reconstructs lights from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Lights(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("Lights"))
            throw new MalformedStringException("Invalid string for Lights.");
        try {
            this.type = LightType.valueOf(parts[1]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid light type in Lights string.");
        }
        this.isAdaptive = Boolean.parseBoolean(parts[2]);
        this.hasDaytimeRunning = Boolean.parseBoolean(parts[3]);
    }

    /** @return a string that can later be passed to {@link #Lights(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + type + DELIMITER + isAdaptive + DELIMITER + hasDaytimeRunning;
    }

    /** @return repair cost based on bulb type, adaptive steering, and DRLs */
    public Money calculateRepairCost() {

        long cost;
        switch (type) {
            case HALOGEN: cost = 60;  break;
            case LED: cost = 200; break;
            case XENON: cost = 350; break;
            case LASER: cost = 600; break;
            default: cost = 60;
        }

        if (isAdaptive) cost += 100;
        if (hasDaytimeRunning) cost += 30;

        return new Money(cost);
    }

    /** @return a human-readable description of the lights */
    public String toString(){
        return (isAdaptive? "Adaptive ": "") + type + " lights" + (hasDaytimeRunning?" with day time running.": " without day time running.");
    }

    /** @return a deep copy of these lights */
    public Lights clone() {
        try {
            return (Lights) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
