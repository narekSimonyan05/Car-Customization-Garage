package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The suspension/amortization unit. Wear percentage and shock type drive the
 * repair cost; over 80% wear flags the part as needing replacement.
 */
public class Amortization implements Repairable, Cloneable {

    /** Type of shock absorber used in the suspension. */
    public enum ShockType {
        /** Gas-filled shock. */ GAS,
        /** Hydraulic (oil) shock. */ HYDRAULIC,
        /** Air shock. */ AIR
    }

    private ShockType type;
    private int wearPercentage;
    private boolean isAdjustable;
    private String DELIMITER = "%%";

    /**
     * @param type           the shock type
     * @param wearPercentage current wear in percent; must be in [0, 100]
     * @param isAdjustable   whether the suspension is adjustable
     * @throws UnrealisticException if {@code wearPercentage} is out of range
     */
    public Amortization(ShockType type, int wearPercentage, boolean isAdjustable) throws UnrealisticException {
        if (wearPercentage < 0 || wearPercentage > 100)
            throw new UnrealisticException("Amortization wear must be 0-100");
        this.type = type;
        this.wearPercentage = wearPercentage;
        this.isAdjustable = isAdjustable;
    }

    /**
     * Reconstructs an amortization from its storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Amortization(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("Amortization"))
            throw new MalformedStringException("Invalid string for Amortization.");
        try {
            this.type = ShockType.valueOf(parts[1]);
            this.wearPercentage = Integer.parseInt(parts[2]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid field in Amortization string.");
        }
        if (wearPercentage < 0 || wearPercentage > 100)
            throw new MalformedStringException("Wear percentage out of range.");
        this.isAdjustable = Boolean.parseBoolean(parts[3]);
    }

    /** @return a string that can later be passed to {@link #Amortization(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + type + DELIMITER + wearPercentage + DELIMITER + isAdjustable;
    }

    /** @return {@code true} when wear exceeds 80% */
    public boolean needsReplacement() {
        return wearPercentage > 80;
    }

    /** @return repair cost based on shock type, wear, and adjustability */
    public Money calculateRepairCost() {
        long cost;
        switch (type) {
            case GAS: cost = 250; break;
            case HYDRAULIC: cost = 200; break;
            case AIR: cost = 600; break;
            default: cost = 250;
        }

        if (needsReplacement()) cost += 350;
        else if (wearPercentage < 50) cost += 120;
        else cost += 40;

        if (isAdjustable) cost += 80;
        return new Money(cost);
    }

    /** @return a human-readable description of the amortization */
    public String toString() {
        return type + " shock type, " + wearPercentage + "% condition" +
                (isAdjustable ? " (adjustable)" : "") +
                (needsReplacement() ? " [NEEDS REPLACEMENT]" : "");
    }

    /** @return a deep copy of this amortization */
    public Amortization clone() {
        try {
            return (Amortization) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
