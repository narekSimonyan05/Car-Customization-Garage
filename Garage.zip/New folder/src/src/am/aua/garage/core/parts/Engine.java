package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The vehicle's engine. Repair cost depends on fuel type, horsepower bracket,
 * cylinder count, and whether the engine is turbocharged.
 */
public class Engine implements Repairable, Cloneable {

    /** What the engine burns or runs on. */
    public enum FuelType {
        /** Petrol (gasoline). */ PETROL,
        /** Diesel. */ DIESEL,
        /** Pure electric. */ ELECTRIC,
        /** Hybrid (combustion + electric). */ HYBRID
    };

    private int horsePower;
    private FuelType fuelType;
    private int cylinderCount;
    private boolean isTurbocharged;
    private String DELIMITER = "%%";

    /**
     * @param horsePower horsepower; must be in (0, 6000)
     * @param fuelType fuel type
     * @param cylinderCount cylinder count; must be in [0, 16]
     * @param isTurbocharged whether the engine has a turbo
     * @throws UnrealisticException if any value is out of range
     */
    public Engine(int horsePower, FuelType fuelType, int cylinderCount, boolean isTurbocharged) throws UnrealisticException {
        if (horsePower <= 0 || horsePower >= 6000) throw new UnrealisticException("Horsepower should be 0-6000");
        if (cylinderCount < 0 || cylinderCount > 16) throw new UnrealisticException("Cylinder count should be 0-16");
        this.horsePower = horsePower;
        this.fuelType = fuelType;
        this.cylinderCount = cylinderCount;
        this.isTurbocharged = isTurbocharged;
    }

    /**
     * Reconstructs an engine from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Engine(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 5 || !parts[0].equals("Engine"))
            throw new MalformedStringException("Invalid string for Engine.");
        try {
            this.horsePower = Integer.parseInt(parts[1]);
            this.fuelType = FuelType.valueOf(parts[2]);
            this.cylinderCount = Integer.parseInt(parts[3]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid field in Engine string.");
        }
        if (horsePower <= 0 || horsePower >= 6000) throw new MalformedStringException("Horsepower out of range.");
        if (cylinderCount < 0 || cylinderCount > 16) throw new MalformedStringException("Cylinder count out of range.");
        this.isTurbocharged = Boolean.parseBoolean(parts[4]);
    }

    /** @return a string that can later be passed to {@link #Engine(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + horsePower + DELIMITER + fuelType + DELIMITER + cylinderCount + DELIMITER + isTurbocharged;
    }

    /** @return repair cost based on fuel type, horsepower, cylinders, and turbo */
    public Money calculateRepairCost() {
        long cost;
        switch (fuelType) {
            case PETROL: cost = 410; break;
            case DIESEL: cost = 600; break;
            case ELECTRIC: cost = 750; break;
            case HYBRID: cost = 850; break;
            default: cost = 400;
        }

        if (horsePower < 120) cost += 100;
        else if (horsePower < 180)  cost += 200;
        else if (horsePower < 250)  cost += 400;
        else if (horsePower < 350)  cost += 700;
        else cost += 1100;

        if (cylinderCount <= 3) cost += 40;
        else if (cylinderCount <= 4) cost += 80;
        else if (cylinderCount <= 6) cost += 150;
        else cost += 250;

        if (isTurbocharged) cost += 250;

        return new Money(cost);
    }

    /** @return a human-readable description of the engine */
    public String toString(){
        return fuelType + " engine with " + horsePower +  " horsepower, " +
                cylinderCount + " cylinders" + (isTurbocharged ? " and with turbo.": ".");
    }

    /** @return the engine's horsepower rating */
    public int getHorsePower(){
        return horsePower;
    }

    /** @return a clone of this engine */
    public Engine clone() {
        try {
            return (Engine) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
