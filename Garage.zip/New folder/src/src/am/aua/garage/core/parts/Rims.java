    package am.aua.garage.core.parts;

    import am.aua.garage.core.*;
    import am.aua.garage.exceptions.MalformedStringException;
    import am.aua.garage.exceptions.UnrealisticException;

    /**
     * Wheel rim. Repair cost depends on rim diameter, material, and spoke count.
     */
    public class Rims implements Repairable, Cloneable {

        /** Material the rim is made of. */
        public enum Material {
            /** Alloy (most common). */ ALLOY,
            /** Steel (cheapest). */ STEEL,
            /** Carbon fiber (premium). */ CARBON
        };

        private int diameterInch;
        private int spokeCount;
        private Material material;
        private String DELIMITER = "%%";

        /**
         * @param diameterInch rim diameter in inches; must be in [12, 26]
         * @param material     rim material
         * @param spokeCount   spoke count; must be in [4, 8]
         * @throws UnrealisticException if either numeric value is out of range
         */
        public Rims(int diameterInch, Material material,int spokeCount) throws UnrealisticException {
            if (diameterInch < 12 || diameterInch > 26)
                throw new UnrealisticException("Rim diameter should be 12-26 inch.");
            if (spokeCount < 4 || spokeCount > 8){
                throw new UnrealisticException("Rim spoke count should be 4-8.");
            }
            this.diameterInch = diameterInch;
            this.material = material;
            this.spokeCount = spokeCount;
        }

        /**
         * Reconstructs rims from a storage string.
         *
         * @param s a string produced by {@link #getStorageString()}
         * @throws MalformedStringException if the string can't be parsed
         */
        public Rims(String s) throws MalformedStringException {
            String[] parts = s.split("%%");
            if (parts.length != 4 || !parts[0].equals("Rims"))
                throw new MalformedStringException("Invalid string for Rims.");
            try {
                this.diameterInch = Integer.parseInt(parts[1]);
                this.material = Material.valueOf(parts[2]);
                this.spokeCount = Integer.parseInt(parts[3]);
            } catch (IllegalArgumentException e) {
                throw new MalformedStringException("Invalid field in Rims string.");
            }
            if (diameterInch < 12 || diameterInch > 26) throw new MalformedStringException("Rim diameter out of range.");
            if (spokeCount < 4 || spokeCount > 8) throw new MalformedStringException("Spoke count out of range.");
        }

        /** @return a string that can later be passed to {@link #Rims(String)} */
        public String getStorageString(){
            return getClass().getSimpleName() + DELIMITER + diameterInch + DELIMITER + material + DELIMITER + spokeCount;
        }

        /** @return repair cost based on material, diameter, and spokes */
        public Money calculateRepairCost() {
            long cost;
            switch (material) {
                case STEEL: cost = 80;  break;
                case ALLOY: cost = 160; break;
                case CARBON: cost = 350; break;
                default: cost = 160;
            }

            if (diameterInch < 16) cost += 0;
            else if (diameterInch < 18) cost += 40;
            else if (diameterInch < 20) cost += 80;
            else cost += 150;

            if (spokeCount > 4){
                cost += 100;
            }

            return new Money(cost);
        }

        /** @return a human-readable description of the rims */
        public String toString(){
            return material + " rim with " + diameterInch + "-inch diameter  " + spokeCount + " spokes.";
        }

        /** @return a deep copy of these rims */
        public Rims clone() {
            try {
                return (Rims) super.clone();
            } catch (CloneNotSupportedException e) {
                return null;
            }
        }
    }
