package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;

/**
 * Single side mirror. Repair cost is a flat base plus a surcharge if the
 * mirror has camera assist.
 */
public class SideMirror implements Repairable, Cloneable {

    /** Which side of the vehicle the mirror is mounted on. */
    public enum Side {
        /** Left mirror. */ LEFT,
        /** Right mirror. */ RIGHT
    }

    private Side side;
    private boolean hasCameraAssist;
    private String DELIMITER = "%%";

    /**
     * @param side             which side of the car
     * @param hasCameraAssist  whether the mirror integrates a camera
     */
    public SideMirror(Side side, boolean hasCameraAssist) {
        this.side = side;
        this.hasCameraAssist = hasCameraAssist;
    }

    /**
     * Reconstructs a side mirror from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public SideMirror(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 3 || !parts[0].equals("SideMirror"))
            throw new MalformedStringException("Invalid string for SideMirror.");
        try {
            this.side = Side.valueOf(parts[1]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid side in SideMirror string.");
        }
        this.hasCameraAssist = Boolean.parseBoolean(parts[2]);
    }

    /** @return a string that can later be passed to {@link #SideMirror(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + side + DELIMITER + hasCameraAssist;
    }

    /** @return base cost plus a surcharge if camera assist is fitted */
    public Money calculateRepairCost() {
        long cost = 80;

        if (hasCameraAssist) cost += 250;
        return new Money(cost);
    }

    /** @return a human-readable description of the side mirror */
    public String toString() {
        return side + " mirror" + (hasCameraAssist ? ",with camera assist." : ".");
    }

    /** @return a deep copy of this side mirror */
    public SideMirror clone() {
        try {
            return (SideMirror) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
