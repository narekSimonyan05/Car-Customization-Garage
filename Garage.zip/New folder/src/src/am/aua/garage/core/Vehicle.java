package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.core.parts.*;

/**
 * Base class for every vehicle the garage knows about. Each vehicle has a
 * brand, a name, a color, and the eleven swappable parts. Concrete subclasses
 * ({@link Sedan}, {@link Suv}) layer extra type-specific options on top.
 *
 * <p>Implements {@link Upgradable} so individual parts can be replaced and
 * {@link Repairable} so the total repair cost can be summed.
 */
public abstract class Vehicle implements Upgradable, Repairable, Cloneable {
    private Brand brand;
    private String name;
    private Color color;
    private Accumulator accumulator;
    private BrakePads brakePads;
    private Engine engine;
    private Gearbox gearbox;
    private Amortization amortization;
    private Bumper bumper;
    private Lights lights;
    private Rims rims;
    private SideMirror sideMirror;
    private Tires tires;
    private Windscreen windscreen;

    /** Field separator used inside a vehicle's storage string. */
    protected String DELIMITER = "##";

    /**
     * Builds a vehicle from its individual parts.
     *
     * @param brand        the manufacturer
     * @param name         the vehicle's name
     * @param color        the body color
     * @param accumulator  the battery
     * @param brakePads    the brake pads
     * @param engine       the engine
     * @param gearbox      the transmission
     * @param amortization the suspension
     * @param bumper       the bumper
     * @param lights       the headlights
     * @param rims         the rims
     * @param sideMirror   the side mirror
     * @param tires        the tires
     * @param windscreen   the windscreen
     */
    public Vehicle(Brand brand,String name, Color color, Accumulator accumulator, BrakePads brakePads,
                   Engine engine, Gearbox gearbox,
                   Amortization amortization, Bumper bumper, Lights lights,
                   Rims rims, SideMirror sideMirror, Tires tires, Windscreen windscreen) {
        this.brand = brand;
        this.name = name;
        this.color = color;
        this.accumulator = accumulator;
        this.brakePads = brakePads;
        this.engine = engine;
        this.gearbox = gearbox;
        this.amortization = amortization;
        this.bumper = bumper;
        this.lights = lights;
        this.rims = rims;
        this.sideMirror = sideMirror;
        this.tires = tires;
        this.windscreen = windscreen;
    }

    /**
     * Reconstructs the {@link Vehicle} portion of a storage string. Subclass
     * constructors call {@code super(s)} and then parse their extra fields.
     *
     * @param s a storage string with at least 15 fields
     * @throws MalformedStringException if the string can't be parsed
     */
    public Vehicle(String s) throws MalformedStringException {
        String[] parts = s.split(DELIMITER);
        if (parts.length < 15)
            throw new MalformedStringException("Vehicle string has too few fields.");
        this.brand = new Brand(parts[1]);
        this.name = parts[2];
        try {
            this.color = Color.valueOf(parts[3]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid color in Vehicle string.");
        }
        this.accumulator = new Accumulator(parts[4]);
        this.brakePads = new BrakePads(parts[5]);
        this.engine = new Engine(parts[6]);
        this.gearbox = new Gearbox(parts[7]);
        this.amortization = new Amortization(parts[8]);
        this.bumper = new Bumper(parts[9]);
        this.lights = new Lights(parts[10]);
        this.rims = new Rims(parts[11]);
        this.sideMirror = new SideMirror(parts[12]);
        this.tires = new Tires(parts[13]);
        this.windscreen = new Windscreen(parts[14]);
    }

    /**
     * Sums the repair cost of every part on the vehicle.
     *
     * @return the total repair cost
     */
    public Money calculateRepairCost(){
        Money total = new Money(0);
        total.add(getEngine().calculateRepairCost());
        total.add(getAccumulator().calculateRepairCost());
        total.add(getBrakePads().calculateRepairCost());
        total.add(getGearbox().calculateRepairCost());
        total.add(getAmortization().calculateRepairCost());
        total.add(getBumper().calculateRepairCost());
        total.add(getLights().calculateRepairCost());
        total.add(getRims().calculateRepairCost());
        total.add(getSideMirror().calculateRepairCost());
        total.add(getTires().calculateRepairCost());
        total.add(getWindscreen().calculateRepairCost());
        return total;
    }

    /** @return the manufacturer */
    public Brand getBrand() {
        return brand;
    }

    /** @return the body color */
    public Color getColor() {
        return color;
    }

    /** @return the accumulator */
    public Accumulator getAccumulator() {
        return accumulator;
    }

    /** @return the brake pads */
    public BrakePads getBrakePads() {
        return brakePads;
    }

    /** @return the engine */
    public Engine getEngine() {
        return engine;
    }

    /** @return the gearbox */
    public Gearbox getGearbox() {
        return gearbox;
    }

    /** @return the amortization */
    public Amortization getAmortization() {
        return amortization;
    }

    /** @return the bumper */
    public Bumper getBumper() {
        return bumper;
    }

    /** @return the lights */
    public Lights getLights() {
        return lights;
    }

    /** @return the rims */
    public Rims getRims() {
        return rims;
    }

    /** @return the side mirror */
    public SideMirror getSideMirror() {
        return sideMirror;
    }

    /** @return the tires */
    public Tires getTires() {
        return tires;
    }

    /** @return the windscreen */
    public Windscreen getWindscreen() {
        return windscreen;
    }

    /** @param color the new body color */
    public void setColor(Color color) {
        this.color = color;
    }

    /** {@inheritDoc} */
    public void changeEngine(Engine newEngine){
        engine = newEngine;
    }

    /** {@inheritDoc} */
    public void changeAccumulator(Accumulator newAccumulator){
        accumulator = newAccumulator;
    }

    /** {@inheritDoc} */
    public void changeBrakePads(BrakePads newBrakePads){
        brakePads = newBrakePads;
    }

    /** {@inheritDoc} */
    public void changeGearbox(Gearbox newGearbox){
        gearbox = newGearbox;
    }

    /** {@inheritDoc} */
    public void changeAmortization(Amortization newAmortization){
        amortization = newAmortization;
    }

    /** {@inheritDoc} */
    public void changeBumper(Bumper newBamper){
        bumper = newBamper;
    }

    /** {@inheritDoc} */
    public void changeLights(Lights newLights){
        lights = newLights;
    }

    /** {@inheritDoc} */
    public void changeRims(Rims newRim){
        rims = newRim;
    }

    /** {@inheritDoc} */
    public void changeSideMirrors(SideMirror newSideMirror){
        sideMirror = newSideMirror;
    }

    /** {@inheritDoc} */
    public void changeTires(Tires newTires){
        tires = newTires;
    }

    /** {@inheritDoc} */
    public void changeWindScreen(Windscreen newWindScreen){
        windscreen = newWindScreen;
    }

    /**
     * @return a "##"-delimited storage string starting with the concrete subclass name
     */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + brand.getStorageString()
                + DELIMITER + name + DELIMITER + color
                + DELIMITER + accumulator.getStorageString()
                + DELIMITER + brakePads.getStorageString()
                + DELIMITER + engine.getStorageString()
                + DELIMITER + gearbox.getStorageString()
                + DELIMITER + amortization.getStorageString()
                + DELIMITER + bumper.getStorageString()
                + DELIMITER + lights.getStorageString()
                + DELIMITER + rims.getStorageString()
                + DELIMITER + sideMirror.getStorageString()
                + DELIMITER + tires.getStorageString()
                + DELIMITER + windscreen.getStorageString();
    }

    /** @return a multi-line printable description of the vehicle */
    public String toString() {
        return name + " Details:" +
                "\n  Brand: " + brand.getName() +
                "\n  Color: " + color +
                "\n  Engine: " + engine +
                "\n  Accumulator: " + accumulator +
                "\n  Brake Pads: " + brakePads +
                "\n  Gearbox: " + gearbox +
                "\n  Amortization: " + amortization +
                "\n  Bumper: " + bumper +
                "\n  Lights: " + lights +
                "\n  Rims: " + rims +
                "\n  Side Mirror: " + sideMirror +
                "\n  Tires: " + tires +
                "\n  Windscreen: " + windscreen;
    }

    /**
     * @return a deep copy of this vehicle: brand and every part are cloned
     */
    public Vehicle clone() {
        try {
            Vehicle copy = (Vehicle) super.clone();
            copy.brand = this.brand.clone();
            copy.accumulator = this.accumulator.clone();
            copy.brakePads = this.brakePads.clone();
            copy.engine = this.engine.clone();
            copy.gearbox = this.gearbox.clone();
            copy.amortization = this.amortization.clone();
            copy.bumper = this.bumper.clone();
            copy.lights = this.lights.clone();
            copy.rims = this.rims.clone();
            copy.sideMirror = this.sideMirror.clone();
            copy.tires = this.tires.clone();
            copy.windscreen = this.windscreen.clone();
            return copy;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
