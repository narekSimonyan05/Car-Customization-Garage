package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;

/**
 * Front or rear bumper. Material, position, and the presence of parking
 * sensors determine the repair cost.
 */
public class Bumper implements Repairable, Cloneable {

    /** Where the bumper is mounted. */
    public enum Position {
        /** Front bumper. */ FRONT,
        /** Rear bumper. */ REAR
    }

    /** What the bumper is made of. */
    public enum Material {
        /** Plastic (cheap, light). */ PLASTIC,
        /** Carbon fiber (premium, light, expensive). */ CARBON,
        /** Steel (heavy, durable). */ STEEL
    }

    private Position position;
    private Material material;
    private boolean hasParkingSensors;
    private String DELIMITER = "%%";

    /**
     * @param position          front or rear
     * @param material          the bumper material
     * @param hasParkingSensors whether the bumper contains parking sensors
     */
    public Bumper(Position position, Material material, boolean hasParkingSensors) {
        this.position = position;
        this.material = material;
        this.hasParkingSensors = hasParkingSensors;
    }

    /**
     * Reconstructs a bumper from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Bumper(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("Bumper"))
            throw new MalformedStringException("Invalid string for Bumper.");
        try {
            this.position = Position.valueOf(parts[1]);
            this.material = Material.valueOf(parts[2]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid enum field in Bumper string.");
        }
        this.hasParkingSensors = Boolean.parseBoolean(parts[3]);
    }

    /** @return a string that can later be passed to {@link #Bumper(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + position + DELIMITER + material + DELIMITER + hasParkingSensors;
    }

    /** @return repair cost based on material, position, and sensors */
    public Money calculateRepairCost() {
        long cost;
        switch (material) {
            case PLASTIC: cost = 180; break;
            case STEEL: cost = 280; break;
            case CARBON: cost = 700; break;
            default: cost = 180;
        }

        if (position == Position.FRONT) cost += 80;
        else cost += 50;

        if (hasParkingSensors) cost += 120;

        return new Money(cost);
    }

    /** @return a human-readable description of the bumper */
    public String toString(){
        return material + " " + position + " bumper" + (hasParkingSensors? " with parking sensors.":" without parking sensors.");
    }

    /** @return a deep copy of this bumper */
    public Bumper clone() {
        try {
            return (Bumper) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
