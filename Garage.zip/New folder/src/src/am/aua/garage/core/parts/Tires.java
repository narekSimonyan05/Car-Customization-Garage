package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The tires. Repair cost depends on the season they're rated for and the
 * rim diameter they're sized to fit.
 */
public class Tires implements Repairable, Cloneable {

    /** Season the tire is rated for. */
    public enum Season {
        /** Summer compound. */ SUMMER,
        /** Winter compound. */ WINTER,
        /** All-season compound. */ ALL_SEASON
    }

    private int rimDiameterInch;
    private Season season;
    private String DELIMITER = "%%";

    /**
     * @param rimDiameterInch matching rim diameter in inches; must be in [12, 26]
     * @param season          season rating
     * @throws UnrealisticException if {@code rimDiameterInch} is out of range
     */
    public Tires(int rimDiameterInch, Season season) throws UnrealisticException {
        if (rimDiameterInch < 12 || rimDiameterInch > 26)
            throw new UnrealisticException("Tire diameter should be 12-26.");
        this.rimDiameterInch = rimDiameterInch;
        this.season = season;
    }

    /**
     * Reconstructs tires from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Tires(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 3 || !parts[0].equals("Tires"))
            throw new MalformedStringException("Invalid string for Tires.");
        try {
            this.rimDiameterInch = Integer.parseInt(parts[1]);
            this.season = Season.valueOf(parts[2]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid field in Tires string.");
        }
        if (rimDiameterInch < 12 || rimDiameterInch > 26)
            throw new MalformedStringException("Tire diameter out of range.");
    }

    /** @return a string that can later be passed to {@link #Tires(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + rimDiameterInch + DELIMITER + season;
    }

    /** @return repair cost based on season and rim diameter */
    public Money calculateRepairCost() {

        long cost;
        switch (season) {
            case SUMMER: cost = 90;  break;
            case ALL_SEASON: cost = 110; break;
            case WINTER: cost = 140; break;
            default: cost = 110;
        }

        if (rimDiameterInch < 16) cost += 0;
        else if (rimDiameterInch < 18) cost += 30;
        else if (rimDiameterInch < 20) cost += 60;
        else cost += 100;

        return new Money(cost);
    }

    /** @return a human-readable description of the tires */
    public String toString(){
        return season + " tires with " + rimDiameterInch + " rim diameter";
    }

    /** @return a deep copy of these tires */
    public Tires clone() {
        try {
            return (Tires) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
