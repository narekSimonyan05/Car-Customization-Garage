package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.core.parts.*;

/**
 * A sport-utility vehicle. Adds five options on top of {@link Vehicle}:
 * 4x4 drivetrain, locking differential, hill descent control, roof rack
 * load capacity, and towing capacity. Repair cost is also marked up 20%
 * compared to the base vehicle to reflect SUV complexity.
 */
public class Suv extends Vehicle implements Cloneable {

    private boolean is4x4;
    private boolean hasLockingDifferential;
    private boolean hasHillDescentControl;
    private int roofRackLoadCapacity;
    private int towingCapacityKg;

    /**
     * Builds an SUV from explicit fields.
     *
     * @param brand                  the manufacturer
     * @param name                   the vehicle name
     * @param color                  the body color
     * @param accumulator            the battery
     * @param brakePads              the brake pads
     * @param engine                 the engine
     * @param gearbox                the transmission
     * @param amortization           the suspension
     * @param bumper                 the bumper
     * @param lights                 the headlights
     * @param rims                   the rims
     * @param sideMirror             the side mirror
     * @param tires                  the tires
     * @param windscreen             the windscreen
     * @param is4x4                  whether the SUV has 4x4 drive
     * @param hasLockingDifferential whether it has a locking differential
     * @param hasHillDescentControl  whether it has hill descent control
     * @param roofRackLoadCapacity   roof rack capacity in kilograms
     * @param towingCapacityKg       towing capacity in kilograms
     */
    public Suv(Brand brand, String name, Color color, Accumulator accumulator, BrakePads brakePads, Engine engine, Gearbox gearbox,
               Amortization amortization, Bumper bumper, Lights lights,
               Rims rims, SideMirror sideMirror, Tires tires,
               Windscreen windscreen, boolean is4x4, boolean hasLockingDifferential,
               boolean hasHillDescentControl, int roofRackLoadCapacity, int towingCapacityKg) {
        super(brand,name, color, accumulator, brakePads, engine, gearbox, amortization, bumper, lights, rims, sideMirror, tires, windscreen);
        this.is4x4 = is4x4;
        this.hasLockingDifferential = hasLockingDifferential;
        this.hasHillDescentControl = hasHillDescentControl;
        this.roofRackLoadCapacity = roofRackLoadCapacity;
        this.towingCapacityKg = towingCapacityKg;
    }

    /**
     * Reconstructs an SUV from its storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Suv(String s) throws MalformedStringException {
        super(s);
        String[] parts = s.split(DELIMITER);
        if (!parts[0].equals("Suv"))
            throw new MalformedStringException("Invalid type tag for Suv.");
        if (parts.length < 20)
            throw new MalformedStringException("Suv string has too few fields.");
        try {
            this.is4x4 = Boolean.parseBoolean(parts[15]);
            this.hasLockingDifferential = Boolean.parseBoolean(parts[16]);
            this.hasHillDescentControl = Boolean.parseBoolean(parts[17]);
            this.roofRackLoadCapacity = Integer.parseInt(parts[18]);
            this.towingCapacityKg = Integer.parseInt(parts[19]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException("Invalid numeric field in Suv string.");
        }
    }

    /**
     * @return base repair cost marked up 20% plus SUV-specific surcharges
     */
    public Money calculateRepairCost() {
        long tmp = super.calculateRepairCost().getCents();
        Money repairCost = new Money(Math.round(tmp * 1.2));

        if (is4x4){
            repairCost.add(new Money(20.5));
        }
        if (hasLockingDifferential){
            repairCost.add(new Money(50.0));
        }
        if (hasHillDescentControl){
            repairCost.add(new Money(27.8));
        }
        if (roofRackLoadCapacity > 200){
            repairCost.add(new Money(300.0));
        }
        if (towingCapacityKg > 5000){
            repairCost.add(new Money(1000.0));
        }
        return repairCost;
    }

    /** @return the parent's storage string with the SUV-specific fields appended */
    public String getStorageString(){
        return super.getStorageString() + DELIMITER + is4x4 + DELIMITER + hasLockingDifferential
                + DELIMITER + hasHillDescentControl + DELIMITER + roofRackLoadCapacity
                + DELIMITER + towingCapacityKg;
    }

    /** @return a multi-line description prefixed with "SUV -" */
    public String toString() {
        return  "SUV - " + super.toString() +
                "\n  Drivetrain: " + (is4x4 ? "4x4" : "2WD") +
                "\n  Locking Differential: " + (hasLockingDifferential ? "yes" : "no") +
                "\n  Hill Descent Control: " + (hasHillDescentControl ? "yes" : "no") +
                "\n  Roof Rack Load Capacity: " + roofRackLoadCapacity +
                "\n  Towing Capacity: " + towingCapacityKg + " kg";
    }

    /** @return a deep copy of this SUV */
    public Suv clone() {
        return (Suv) super.clone();
    }
}
