package am.aua.garage.core;

import am.aua.garage.core.parts.*;

/**
 * Contract for vehicles whose individual parts can be swapped out one at a
 * time. Each method replaces the matching part with the supplied instance.
 */
public interface Upgradable {

    /** Replaces the engine. @param e the new engine */
    void changeEngine(Engine e);

    /** Replaces the accumulator (battery). @param a the new accumulator */
    void changeAccumulator(Accumulator a);

    /** Replaces the brake pads. @param b the new brake pads */
    void changeBrakePads(BrakePads b);

    /** Replaces the gearbox. @param g the new gearbox */
    void changeGearbox(Gearbox g);

    /** Replaces the amortization (suspension). @param am the new amortization */
    void changeAmortization(Amortization am);

    /** Replaces the bumper. @param bam the new bumper */
    void changeBumper(Bumper bam);

    /** Replaces the lights. @param l the new lights */
    void changeLights(Lights l);

    /** Replaces the rims. @param r the new rims */
    void changeRims(Rims r);

    /** Replaces the side mirrors. @param s the new side mirror */
    void changeSideMirrors(SideMirror s);

    /** Replaces the tires. @param t the new tires */
    void changeTires(Tires t);

    /** Replaces the windscreen. @param w the new windscreen */
    void changeWindScreen(Windscreen w);
}
