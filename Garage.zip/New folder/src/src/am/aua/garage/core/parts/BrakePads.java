package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The brake pads. Repair cost depends on pad material, wear percentage, and
 * whether ABS is enabled. Pads worn past 80% are flagged for replacement.
 */
public class BrakePads implements Repairable, Cloneable {

    /** The friction material used in the brake pads. */
    public enum Material {
        /** Ceramic (premium, quiet). */ CERAMIC,
        /** Metallic (high heat tolerance). */ METALLIC,
        /** Organic (cheaper, softer). */ ORGANIC
    }

    private Material material;
    private int wearPercentage;
    private boolean isABSEnabled;
    private String DELIMITER = "%%";

    /**
     * @param material        the friction material
     * @param wearPercentage  current wear in percent; must be in [0, 100]
     * @param isABSEnabled    whether ABS is enabled
     * @throws UnrealisticException if {@code wearPercentage} is out of range
     */
    public BrakePads(Material material, int wearPercentage, boolean isABSEnabled) throws UnrealisticException {
        if (wearPercentage < 0 || wearPercentage > 100)
            throw new UnrealisticException("BrakePads wear must be 0-100");
        this.material = material;
        this.wearPercentage = wearPercentage;
        this.isABSEnabled = isABSEnabled;
    }

    /**
     * Reconstructs brake pads from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public BrakePads(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("BrakePads"))
            throw new MalformedStringException("Invalid string for BrakePads.");
        try {
            this.material = Material.valueOf(parts[1]);
            this.wearPercentage = Integer.parseInt(parts[2]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid field in BrakePads string.");
        }
        if (wearPercentage < 0 || wearPercentage > 100)
            throw new MalformedStringException("Wear percentage out of range.");
        this.isABSEnabled = Boolean.parseBoolean(parts[3]);
    }

    /** @return a string that can later be passed to {@link #BrakePads(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + material + DELIMITER + wearPercentage + DELIMITER + isABSEnabled;
    }

    /** @return repair cost based on material, wear, and ABS */
    public Money calculateRepairCost() {

        long cost;
        switch (material) {
            case ORGANIC: cost = 100; break;
            case METALLIC: cost = 160; break;
            case CERAMIC: cost = 240; break;
            default: cost = 160;
        }

        if (needsReplacement()) cost += 100;
        else cost += 30;

        if (isABSEnabled) cost += 60;
        return new Money(cost);
    }

    /** @return {@code true} when wear exceeds 80% */
    public boolean needsReplacement() {
        return wearPercentage > 80;
    }

    /** @return a human-readable description of the brake pads */
    public String toString() {
        return material + " brake pads, "
                + (isABSEnabled ? "with ABS, " : "without ABS, ")
                + wearPercentage + "% wear remaining"
                + (needsReplacement() ? " [NEEDS REPLACEMENT]" : "");
    }

    /** @return a deep copy of these brake pads */
    public BrakePads clone() {
        try {
            return (BrakePads) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
