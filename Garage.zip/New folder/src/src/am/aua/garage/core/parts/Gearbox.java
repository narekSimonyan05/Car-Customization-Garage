package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;

/**
 * The transmission. Repair cost depends on transmission type and whether the
 * gearbox drives all four wheels.
 */
public class Gearbox implements Repairable, Cloneable {

    /** Transmission type. */
    public enum TransmissionType {
        /** Manual transmission. */ MANUAL,
        /** Automatic transmission. */ AUTOMATIC
    }

    private TransmissionType type;
    private boolean isAWD;
    private String DELIMITER = "%%";

    /**
     * @param type  manual or automatic
     * @param isAWD whether this gearbox drives all four wheels
     */
    public Gearbox(TransmissionType type,boolean isAWD) {
        this.type = type;
        this.isAWD = isAWD;
    }

    /**
     * Reconstructs a gearbox from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Gearbox(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 3 || !parts[0].equals("Gearbox"))
            throw new MalformedStringException("Invalid string for Gearbox.");
        try {
            this.type = TransmissionType.valueOf(parts[1]);
        } catch (IllegalArgumentException e) {
            throw new MalformedStringException("Invalid transmission type in Gearbox string.");
        }
        this.isAWD = Boolean.parseBoolean(parts[2]);
    }

    /** @return a string that can later be passed to {@link #Gearbox(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + type + DELIMITER + isAWD;
    }

    /** @return repair cost based on transmission type and AWD */
    public Money calculateRepairCost() {
        long cost;
        switch (type) {
            case MANUAL: cost = 650;  break;
            case AUTOMATIC: cost = 1100; break;
            default: cost = 600;
        }

        if (isAWD) cost += 350;

        return new Money(cost);
    }

    /** @return a human-readable description of the gearbox */
    public String toString(){
        return type + (isAWD ? "(AWD)" : "(2WD)");
    }

    /** @return a deep copy of this gearbox */
    public Gearbox clone() {
        try {
            return (Gearbox) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
