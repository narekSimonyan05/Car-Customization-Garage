package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;

/**
 * A monetary amount expressed in cents to avoid floating-point rounding bugs.
 * Values are non-negative; {@link #subtract(Money)} silently no-ops on
 * overdraft and returns {@code false} so the caller can react.
 */
public class Money implements Comparable<Money>{

    private long cents;
    private String DELIMITER = "%%";

    /**
     * @param cents non-negative amount in cents
     * @throws IllegalArgumentException if {@code cents} is negative
     */
    public Money(long cents){
        if (cents < 0)
            throw new IllegalArgumentException ("Money cannot be negative");
        this.cents = cents;
    }

    /**
     * Reconstructs a {@code Money} from its storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed or is negative
     */
    public Money(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 2 || !parts[0].equals("Money"))
            throw new MalformedStringException("Invalid string for Money.");
        try {
            this.cents = Long.parseLong(parts[1]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException("Invalid cents value in Money string.");
        }
        if (this.cents < 0)
            throw new MalformedStringException("Money cents cannot be negative.");
    }

    /** @return a string that can later be passed to {@link #Money(String)} */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + cents;
    }

    /**
     * Convenience constructor that accepts dollars with a decimal part.
     *
     * @param amount the amount in dollars; rounded to the nearest cent
     */
    public Money(double amount){
        this(Math.round(amount * 100));
    }

    /** @return the amount as cents */
    public long getCents(){
        return cents;
    }

    /** @return the amount as dollars (cents divided by 100) */
    public double getAmount(){
        return cents / 100.0;
    }

    /**
     * Adds {@code other} to this amount in place.
     *
     * @param other the amount to add
     * @return {@code true} on success, {@code false} if {@code other} is invalid
     */
    public boolean add(Money other) {
        if (other.cents < 0) return false;
        this.cents += other.cents;
        return true;
    }

    /**
     * Subtracts {@code other} from this amount in place.
     *
     * @param other the amount to subtract
     * @return {@code true} on success, {@code false} if there isn't enough
     */
    public boolean subtract(Money other) {
        if (this.cents < other.cents)
            return false;
        this.cents -= other.cents;
        return true;
    }

    /**
     * @param other the amount to compare against
     * @return {@code true} if this amount is at least {@code other}
     */
    public boolean isGreaterThanOrEqual(Money other) {
        return this.cents >= other.cents;
    }

    /**
     * @param other the other amount
     * @return negative, zero, or positive following {@link Comparable} contract
     */
    public int compareTo(Money other){
        return Long.compare(this.cents, other.cents);
    }

    /** @return the amount formatted as {@code $D.CC} */
    public String toString() {
        return String.format("$%d.%02d", cents / 100, cents % 100);
    }
}
