package am.aua.garage.core.parts;

import am.aua.garage.core.*;
import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The vehicle's battery. Capacity, voltage, and age determine repair cost,
 * and a battery older than 48 months is flagged as needing replacement.
 */
public class Accumulator implements Repairable, Cloneable {
    private double capacityAh;
    private int voltageV;
    private int ageMonths;
    private String DELIMITER = "%%";

    /**
     * Creates a new accumulator.
     *
     * @param capacityAh capacity in amp-hours; must be in (0, 1000]
     * @param voltageV   voltage in volts; must be in [10, 15]
     * @param ageMonths  age in months; must be non-negative
     * @throws UnrealisticException if any value is out of range
     */
    public Accumulator(double capacityAh, int voltageV, int ageMonths) throws UnrealisticException {
        if (capacityAh <= 0 || capacityAh > 1000) throw new UnrealisticException("Capacity should be 0-1000.");
        if (voltageV < 10 || voltageV > 15) throw new UnrealisticException("Voltage should be 10-15.");
        if (ageMonths < 0) throw new UnrealisticException("Accumulator age cannot be negative.");
        this.capacityAh = capacityAh;
        this.voltageV = voltageV;
        this.ageMonths = ageMonths;
    }

    /**
     * Reconstructs an accumulator from its storage string.
     *
     * @param s a string previously produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Accumulator(String s) throws MalformedStringException {
        String[] parts = s.split("%%");
        if (parts.length != 4 || !parts[0].equals("Accumulator"))
            throw new MalformedStringException("Invalid string for Accumulator.");
        try {
            this.capacityAh = Double.parseDouble(parts[1]);
            this.voltageV = Integer.parseInt(parts[2]);
            this.ageMonths = Integer.parseInt(parts[3]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException("Invalid numeric field in Accumulator string.");
        }
        if (capacityAh <= 0 || capacityAh > 1000) throw new MalformedStringException("Capacity out of range.");
        if (voltageV < 10 || voltageV > 15) throw new MalformedStringException("Voltage out of range.");
        if (ageMonths < 0) throw new MalformedStringException("Age cannot be negative.");
    }

    /**
     * @return a string that can later be passed to {@link #Accumulator(String)}
     */
    public String getStorageString(){
        return getClass().getSimpleName() + DELIMITER + capacityAh + DELIMITER + voltageV + DELIMITER + ageMonths;
    }

    /**
     * @return repair cost based on capacity tier, voltage, and age
     */
    public Money calculateRepairCost() {
        long cost;
        if (capacityAh < 55) cost = 90;
        else if (capacityAh < 70) cost = 130;
        else if (capacityAh < 100) cost = 190;
        else if (capacityAh < 120) cost = 260;
        else cost = 350;

        if (voltageV >= 24) cost += 100;

        if (ageMonths > 48) cost += 80;
        else if (ageMonths > 24) cost += 30;

        return new Money(cost);
    }

    /**
     * @return {@code true} when the battery is older than 48 months
     */
    public boolean needsReplacement() {
        return ageMonths > 48;
    }

    /**
     * @return a human-readable description of the accumulator
     */
    public String toString(){
        return voltageV + "V / " + capacityAh + "Ah battery, " + ageMonths + " months old" +
                (needsReplacement() ? " [NEEDS REPLACEMENT]" : "");
    }

    /**
     * @return a deep copy of this accumulator
     */
    public Accumulator clone() {
        try {
            return (Accumulator) super.clone();
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
