package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;

/**
 * The garage itself: a small fleet of {@link Vehicle}s plus a single
 * {@link Wallet}. Capacity is fixed at {@code MAX_VEHICLE_CAPACITY = 5}.
 *
 * <p>The whole garage can be serialized to and reconstructed from a "**"
 * delimited storage string via {@link #getStorageString()} and
 * {@link #Garage(String)}.
 */
public class Garage {

    private final int MAX_VEHICLE_CAPACITY = 5;

    private Vehicle[] vehicles;

    private Wallet wallet;

    private String DELIMITER = "**";

    /**
     * Creates an empty garage with the given wallet.
     *
     * @param wallet the starting wallet
     */
    public Garage(Wallet wallet){
        this.vehicles = new Vehicle[0];
        this.wallet = wallet;
    }

    /**
     * Reconstructs a garage (wallet and all vehicles) from a storage string.
     *
     * @param storageString a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed or
     *         contains an unknown vehicle type
     */
    public Garage(String storageString) throws MalformedStringException {
        String[] parts = storageString.split("\\*\\*");
        if (parts.length < 3 || !parts[0].equals("Garage"))
            throw new MalformedStringException();
        this.wallet = new Wallet(parts[1]);
        int vehicleCount;
        try {
            vehicleCount = Integer.parseInt(parts[2]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException();
        }
        if (parts.length != 3 + vehicleCount)
            throw new MalformedStringException();
        this.vehicles = new Vehicle[vehicleCount];
        for (int i = 0; i < vehicleCount; i++) {
            String vehicleString = parts[3 + i];
            String vehicleType = vehicleString.split("##")[0];
            switch (vehicleType) {
                case "Sedan":
                    this.vehicles[i] = new Sedan(vehicleString);
                    break;
                case "Suv":
                    this.vehicles[i] = new Suv(vehicleString);
                    break;
                default:
                    throw new MalformedStringException();
            }
        }
    }

    /**
     * Adds a clone of {@code vehicle} to the garage if there's room.
     *
     * @param vehicle the vehicle to add (cloned before storing)
     * @return {@code true} on success, {@code false} if the garage is full
     */
    public boolean addNewVehicle(Vehicle vehicle){
        if (isFull()){
            return false;
        }
        int currentLength = (vehicles == null) ? 0 : vehicles.length;
        Vehicle[] temp = new Vehicle[currentLength + 1];
        for (int i = 0; i < currentLength; i++){
            temp[i] = vehicles[i];
        }
        temp[currentLength] = vehicle.clone();
        vehicles = temp;
        return true;
    }

    /**
     * Removes the vehicle at the given index, shifting the rest down.
     *
     * @param index the index of the vehicle to remove
     * @return {@code true} on success, {@code false} if the index is invalid
     */
    public boolean removeVehicle(int index){
        if (index < 0 || index >= vehicles.length){
            return false;
        }
        Vehicle[] temp = new Vehicle[vehicles.length - 1];
        for (int i = 0, j = 0; i < vehicles.length; i++){
            if (i == index)
                continue;
            temp[j] = vehicles[i];
            j++;
        }
        vehicles = temp;
        return true;
    }

    private boolean isFull(){
        return vehicles != null && vehicles.length == MAX_VEHICLE_CAPACITY;
    }

    /** @return the wallet (live reference, not a copy) */
    public Wallet getWallet(){
        return wallet;
    }

    /**
     * Withdraws {@code amount} from the wallet if there are enough funds.
     *
     * @param amount the amount to charge
     * @return {@code true} on success, {@code false} if the wallet is short
     */
    public boolean charge(Money amount){
        if (wallet.getBalance().compareTo(amount) < 0) return false;
        wallet.withdraw(amount);
        return true;
    }

    /**
     * @param index the vehicle index
     * @return the vehicle at that index (live reference)
     */
    public Vehicle getVehicle(int index){
        return vehicles[index];
    }

    /**
     * @return the vehicle array, or {@code null} if the garage is empty
     */
    public Vehicle[] getVehicles(){
        if (vehicles.length == 0) return null;
        return vehicles;
    }

    /** @return the number of vehicles currently parked */
    public int getVehicleCount(){
        return vehicles.length;
    }

    /** @return the maximum number of vehicles the garage can hold */
    public int getMaxCapacity(){
        return MAX_VEHICLE_CAPACITY;
    }

    /** @return a string that can later be passed to {@link #Garage(String)} */
    public String getStorageString(){
        String result = getClass().getSimpleName() + DELIMITER + wallet.getStorageString() + DELIMITER + vehicles.length;
        for (int i = 0; i < vehicles.length; i++){
            result += DELIMITER + vehicles[i].getStorageString();
        }
        return result;
    }

    /** @return a short summary: vehicle count followed by the wallet's text */
    public String toString(){
        return getVehicleCount() + " vehicles in garage\n" + wallet.toString();
    }

}
