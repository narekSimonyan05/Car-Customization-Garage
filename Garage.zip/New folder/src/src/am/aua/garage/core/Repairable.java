package am.aua.garage.core;

/**
 * Implemented by anything that has a repair price tag — vehicles and individual
 * parts both implement this so the cost of fixing a whole car is just the sum
 * of {@link #calculateRepairCost()} of its parts.
 */
public interface Repairable {

    /**
     * Returns the cost of repairing this item in its current condition.
     *
     * @return the repair cost as a {@link Money} instance
     */
    Money calculateRepairCost();
}
