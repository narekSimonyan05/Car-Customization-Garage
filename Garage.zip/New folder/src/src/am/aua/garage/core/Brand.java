package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.exceptions.UnrealisticException;

/**
 * The manufacturer of a {@link Vehicle}. Holds contact info, country of
 * origin, founding year, a luxury flag, and an array of service locations
 * where the brand has authorized service centers.
 */
public class Brand implements Cloneable {

    /**
     * A single service-center address belonging to a {@link Brand}.
     */
    public static class Location implements Cloneable {

        private String city;
        private String country;
        private String address;

        /**
         * @param city    the city
         * @param country the country
         * @param address the street address
         */
        public Location(String city, String country, String address) {
            this.city = city;
            this.country = country;
            this.address = address;
        }

        /**
         * Reconstructs a location from a storage string.
         *
         * @param s a string produced by {@link #getStorageString()}
         * @throws MalformedStringException if the string can't be parsed
         */
        public Location(String s) throws MalformedStringException {
            String[] parts = s.split("%%");
            if (parts.length != 4 || !parts[0].equals("Location"))
                throw new MalformedStringException("Invalid string for Location.");
            this.city = parts[1];
            this.country = parts[2];
            this.address = parts[3];
        }

        /** @return the city */
        public String getCity()    { return city; }

        /** @return the country */
        public String getCountry() { return country; }

        /** @return the street address */
        public String getAddress() { return address; }

        /** @return a printable description of the location */
        public String toString() {
            return country + ", " + city + ", " + address;
        }

        /** @return a string that can later be passed to {@link #Location(String)} */
        public String getStorageString(){
            return getClass().getSimpleName() + "%%" + city + "%%" + country + "%%" + address;
        }

        /** @return a deep copy of this location */
        public Location clone() {
            try {
                return (Location) super.clone();
            } catch (CloneNotSupportedException e) {
                return null;
            }
        }
    }

    private String name;
    private String phoneNumber;
    private String email;
    private String website;
    private String originCountry;
    private Location[] serviceLocations;
    private boolean isLuxury;
    private int foundedYear;
    private String DELIMITER = "%%";

    /**
     * @param name             brand name
     * @param phoneNumber      contact phone number
     * @param email            contact email
     * @param website          public website
     * @param country          country where the brand was founded
     * @param serviceLocations service locations; may be {@code null} for none
     * @param isLuxury         whether the brand is positioned as luxury
     * @param foundedYear      year the brand was founded
     * @throws UnrealisticException reserved; not thrown by the current implementation
     */
    public Brand(String name, String phoneNumber, String email, String website,
                 String country, Location[] serviceLocations,
                 boolean isLuxury, int foundedYear) throws UnrealisticException{
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.website = website;
        this.originCountry = country;
        this.isLuxury = isLuxury;
        this.foundedYear = foundedYear;

        if (serviceLocations != null) {
            this.serviceLocations = new Location[serviceLocations.length];
            for (int i = 0; i < serviceLocations.length; i++)
                this.serviceLocations[i] = serviceLocations[i];
        } else {
            this.serviceLocations = new Location[0];
        }
    }

    private static final int HEADER_FIELDS = 9;
    private static final int FIELDS_PER_LOCATION = 4;

    /**
     * Reconstructs a brand (with all its locations) from a storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Brand(String s) throws MalformedStringException {
        String[] parts = s.split("%%", -1);
        if (parts.length < HEADER_FIELDS || !parts[0].equals("Brand"))
            throw new MalformedStringException("Invalid string for Brand.");
        int n;
        try {
            n = Integer.parseInt(parts[8]);
            this.foundedYear = Integer.parseInt(parts[7]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException("Invalid numeric field in Brand string.");
        }
        if (parts.length != HEADER_FIELDS + n * FIELDS_PER_LOCATION)
            throw new MalformedStringException("Brand string has wrong number of parts.");
        this.name = parts[1];
        this.phoneNumber = parts[2];
        this.email = parts[3];
        this.website = parts[4];
        this.originCountry = parts[5];
        this.isLuxury = Boolean.parseBoolean(parts[6]);
        this.serviceLocations = new Location[n];
        for (int i = 0; i < n; i++) {
            int base = HEADER_FIELDS + i * FIELDS_PER_LOCATION;
            if (!parts[base].equals("Location"))
                throw new MalformedStringException("Expected Location token at index " + base + ".");
            this.serviceLocations[i] = new Location(parts[base + 1], parts[base + 2], parts[base + 3]);
        }
    }

    /** @return the brand's name */
    public String getName() {
        return name;
    }

    /** @return the year the brand was founded */
    public int getFoundedYear(){
        return foundedYear;
    }

    /** @return the contact phone number */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /** @return the contact email address */
    public String getEmail() {
        return email;
    }

    /** @return the brand's public website */
    public String getWebsite() {
        return website;
    }

    /** @return the country where the brand originates */
    public String getCountry() {
        return originCountry;
    }

    /** @return a fresh array containing the service locations */
    public Location[] getServiceLocations() {
        Location[] tmp = new Location[serviceLocations.length];
        for (int i = 0; i < tmp.length;i ++){
            tmp[i] = serviceLocations[i];
        }
        return tmp;
    }

    /** @return {@code true} if this is a luxury brand */
    public boolean isLuxury() {
        return isLuxury;
    }

    /** @param luxury whether the brand is luxury */
    public void setLuxury(boolean luxury) {
        isLuxury = luxury;
    }

    /** @param serviceLocations the new array of service locations (copied) */
    public void setServiceLocations(Location[] serviceLocations) {
        this.serviceLocations = new Location[serviceLocations.length];
        for (int i = 0; i < serviceLocations.length; i ++){
            this.serviceLocations[i] = serviceLocations[i];
        }
    }

    /** @param website the new website URL */
    public void setWebsite(String website) {
        this.website = website;
    }

    /** @param email the new email address */
    public void setEmail(String email) {
        this.email = email;
    }

    /** @param phoneNumber the new phone number */
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /** @return a string that can later be passed to {@link #Brand(String)} */
    public String getStorageString(){
        String result = getClass().getSimpleName() + DELIMITER + name + DELIMITER + phoneNumber + DELIMITER + email
                + DELIMITER + website + DELIMITER + originCountry + DELIMITER + isLuxury
                + DELIMITER + foundedYear + DELIMITER + serviceLocations.length;
        for (int i = 0; i < serviceLocations.length; i++){
            result += DELIMITER + serviceLocations[i].getStorageString();
        }
        return result;
    }

    /** @return a printable description of the brand and its service locations */
    public String toString() {
        String result = (isLuxury ? "Luxury brand " : "") + name + " founded in " + foundedYear + " in the "+ originCountry +
                "\nPhone number: " + phoneNumber +
                "\nEmail address: " + email +
                "\nWebsite: " + website +
                (serviceLocations.length > 0?"\nService locations are: " : ".");

        for(int i = 0 ; i < serviceLocations.length; i ++){
            if (i == serviceLocations.length - 1){
                result += serviceLocations[i];
            }else
                result += serviceLocations[i] + ", ";

        }
        return result;

    }

    /** @return a deep copy of this brand (locations are cloned individually) */
    public Brand clone() {
        try {
            Brand copy = (Brand) super.clone();
            copy.serviceLocations = new Location[this.serviceLocations.length];
            for (int i = 0; i < this.serviceLocations.length; i++) {
                copy.serviceLocations[i] = this.serviceLocations[i].clone();
            }
            return copy;
        } catch (CloneNotSupportedException e) {
            return null;
        }
    }
}
