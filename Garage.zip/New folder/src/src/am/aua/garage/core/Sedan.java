package am.aua.garage.core;

import am.aua.garage.exceptions.MalformedStringException;
import am.aua.garage.core.parts.*;

/**
 * A passenger sedan. Adds three options on top of {@link Vehicle}: a sunroof,
 * sport mode, and an explicit horsepower number that influences repair cost.
 */
public class Sedan extends Vehicle implements Cloneable{

    private boolean hasSunRoof;
    private boolean hasSportMode;
    int horsepower;

    /**
     * Builds a sedan from explicit fields. The {@code horsepower} parameter is
     * overwritten with {@link Engine#getHorsePower()} to keep the two in sync.
     *
     * @param brand        the manufacturer
     * @param name         the vehicle name
     * @param color        the body color
     * @param accumulator  the battery
     * @param brakePads    the brake pads
     * @param engine       the engine
     * @param gearbox      the transmission
     * @param amortization the suspension
     * @param bumper       the bumper
     * @param lights       the headlights
     * @param rims         the rims
     * @param sideMirror   the side mirror
     * @param tires        the tires
     * @param windscreen   the windscreen
     * @param hasSunRoof   whether the sedan has a sunroof
     * @param hasSportMode whether the sedan has a sport mode
     * @param horsepower   horsepower number (overwritten with engine's value)
     */
    public Sedan(Brand brand, String name, Color color, Accumulator accumulator, BrakePads brakePads, Engine engine, Gearbox gearbox,
                 Amortization amortization, Bumper bumper, Lights lights,
                 Rims rims, SideMirror sideMirror, Tires tires, Windscreen windscreen, boolean hasSunRoof,
                 boolean hasSportMode, int horsepower) {
        super(brand,name, color, accumulator, brakePads, engine, gearbox, amortization, bumper, lights, rims, sideMirror, tires, windscreen);
        this.hasSunRoof = hasSunRoof;
        this.hasSportMode = hasSportMode;
        this.horsepower = engine.getHorsePower();
    }

    /**
     * Reconstructs a sedan from its storage string.
     *
     * @param s a string produced by {@link #getStorageString()}
     * @throws MalformedStringException if the string can't be parsed
     */
    public Sedan(String s) throws MalformedStringException {
        super(s);
        String[] parts = s.split(DELIMITER);
        if (!parts[0].equals("Sedan"))
            throw new MalformedStringException("Invalid type tag for Sedan.");
        if (parts.length < 18)
            throw new MalformedStringException("Sedan string has too few fields.");
        try {
            this.hasSunRoof = Boolean.parseBoolean(parts[15]);
            this.hasSportMode = Boolean.parseBoolean(parts[16]);
            this.horsepower = Integer.parseInt(parts[17]);
        } catch (NumberFormatException e) {
            throw new MalformedStringException("Invalid numeric field in Sedan string.");
        }
    }

    /**
     * @return base vehicle repair cost plus sedan-specific surcharges
     */
    public Money calculateRepairCost() {
        Money cost = super.calculateRepairCost();
        if (hasSunRoof){
            cost.add(new Money(300.0));
        }
        if (hasSportMode){
            cost.add(new Money(500.0));
        }
        if (horsepower > 200){
            cost.add(new Money(264.5));
        }
        return cost;
    }

    /** @return the parent's storage string with the sedan-specific fields appended */
    public String getStorageString(){
        return super.getStorageString() + DELIMITER + hasSunRoof + DELIMITER + hasSportMode + DELIMITER + horsepower;
    }

    /** @return a multi-line description prefixed with "Sedan -" */
    public String toString() {
       return "Sedan - " + super.toString() +
                "\n  Sunroof: " + (hasSunRoof ? "yes" : "no") +
                "\n  Sport Mode: " + (hasSportMode ? "yes" : "no") +
                "\n  Horsepower: " + horsepower + " hp";
    }

    /** @return a deep copy of this sedan */
    public Sedan clone() {
        return (Sedan) super.clone();
    }
}
